import React, { useState, useRef, useEffect } from "react";
import { fabric } from "fabric";
import { pdfjs } from "react-pdf";
import "./SideMenus.css";
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

const SideMenus = () => {
  const [canvas, setCanvas] = useState(null);
  const [shapes, setShapes] = useState([]);
  const [shapeVisibility, setShapeVisibility] = useState([]);
  const [eraserMode, setEraserMode] = useState(false);
  const [fillEnabled, setFillEnabled] = useState(false);
  const [fillType, setFillType] = useState("solid");
  const [strokeColor, setStrokeColor] = useState("#000000");
  const [strokeWidth, setStrokeWidth] = useState(2);
  const [fillColor, setFillColor] = useState("#ffffff");
  const [gradientStartColor, setGradientStartColor] = useState("#ffffff");
  const [gradientEndColor, setGradientEndColor] = useState("#000000");
  const [imageURL, setImageURL] = useState("");
  const [outlineColor, setOutlineColor] = useState("#000000");
  const [outlineType, setOutlineType] = useState("solid");
  const [selectedShapeIndex, setSelectedShapeIndex] = useState(null);
  const [tempStrokeColor, setTempStrokeColor] = useState(strokeColor);
  const [tempStrokeWidth, setTempStrokeWidth] = useState(strokeWidth);
  const [tempFillColor, setTempFillColor] = useState(fillColor);
  const [tempOutlineColor, setTempOutlineColor] = useState(outlineColor);
  const [tempOutlineType, setTempOutlineType] = useState(outlineType);
  const [hatchType, setHatchType] = useState("diagonal");
  const [points, setPoints] = useState([]);
  const [drawingPolygon, setDrawingPolygon] = useState(false);

  const canvasContainerRef = useRef(null);
  const freeformPath = useRef(null);

  useEffect(() => {
    const newCanvas = new fabric.Canvas("drawingCanvas", {
      backgroundColor: "#fff",
      width: 800,
      height: 600,
    });
    setCanvas(newCanvas);
  }, []);

  useEffect(() => {
    if (canvas) {
      canvas.isDrawingMode = false;
      canvas.selection = false; // Disable object selection to prevent interference with drawing polygons

    }
  }, [canvas]);

  useEffect(() => {
    if (canvas) {
      canvas.on("selection:created", (e) => {
        const selectedObject = e.target;
        const index = shapes.findIndex((shape) => shape === selectedObject);
        setSelectedShapeIndex(index);
      });
    }
  }, [canvas, shapes]);

  // Function to toggle visibility of a shape

  const toggleShapeVisibility = (index) => {
    const updatedVisibility = [...shapeVisibility];
    updatedVisibility[index] = !updatedVisibility[index];
    setShapeVisibility(updatedVisibility);

    const shape = shapes[index];
    shape.visible = updatedVisibility[index]; // Set visibility on the shape
    canvas.requestRenderAll();
  };

  const toggleEraserMode = () => {
    setEraserMode(!eraserMode);
    if (!canvas) return;
    canvas.isDrawingMode = false;
    canvas.freeDrawingBrush = eraserMode
      ? null
      : new fabric.PencilBrush(canvas);
    canvas.isDrawingMode = eraserMode;
  };

  const addShape = (shape) => {
    if (!canvas) return;
    if (canvas.isDrawingMode) {
      canvas.isDrawingMode = false;
    }
    canvas.add(shape);
    setShapes([...shapes, shape]);
    setShapeVisibility([...shapeVisibility, true]); // Initialize visibility state for the shape
  };

  const duplicateShape = (shape) => {
    if (!canvas || !shape) return;
    if (canvas.isDrawingMode) {
      canvas.isDrawingMode = false;
    }

    fabric.util.enlivenObjects([shape.toObject()], (objects) => {
      const clonedShape = objects[0];
      if (!clonedShape) return;

      clonedShape.set({
        left: shape.left + 20,
        top: shape.top + 20,
      });

      canvas.add(clonedShape);
      setShapes([...shapes, clonedShape]);
      setShapeVisibility([...shapeVisibility, true]); // Initialize visibility state for the cloned shape
      canvas.renderAll();
    });
  };

  const removeShape = (shape) => {
    if (!canvas) return;
    canvas.remove(shape);
    setShapes(shapes.filter((item) => item !== shape));
    setSelectedShapeIndex(null);
  };

  const addRect = () => {
    const fillValue = fillType === "image" ? createImageFill() : getFillValue();
    const rect = new fabric.Rect({
      left: 100,
      top: 100,
      width: 100,
      height: 100,
      fill: fillType === "image" ? "" : fillValue,
      stroke: strokeColor,
      strokeWidth: strokeWidth,
      strokeDashArray:
        outlineType === "dashed"
          ? [5, 5]
          : outlineType === "dotted"
          ? [1, strokeWidth * 2]
          : null,
          visible: true, // Initially visible
    });

    if (fillType === "image" && fillValue) {
      rect.setPatternFill({
        source: fillValue,
        repeat: "repeat",
      });
    }

    addShape(rect);
  };

  const addCircle = () => {
    const fillValue = fillType === "image" ? createImageFill() : getFillValue();
    const circle = new fabric.Circle({
      left: 200,
      top: 200,
      radius: 50,
      fill: fillType === "image" ? "" : fillValue,
      stroke: strokeColor,
      strokeWidth: strokeWidth,
      strokeDashArray:
        outlineType === "dashed"
          ? [5, 5]
          : outlineType === "dotted"
          ? [1, strokeWidth * 2]
          : null,
          visible: true, // Initially visible
    });

    if (fillType === "image" && fillValue) {
      circle.setPatternFill({
        source: fillValue,
        repeat: "repeat",
      });
    }

    addShape(circle);
  };

  const addTriangle = () => {
    const fillValue = fillType === "image" ? createImageFill() : getFillValue();
    const triangle = new fabric.Triangle({
      left: 300,
      top: 300,
      width: 100,
      height: 100,
      fill: fillType === "image" ? "" : fillValue,
      stroke: strokeColor,
      strokeWidth: strokeWidth,
      strokeDashArray:
        outlineType === "dashed"
          ? [5, 5]
          : outlineType === "dotted"
          ? [1, strokeWidth * 2]
          : null,
          visible: true, // Initially visible
    });

    if (fillType === "image" && fillValue) {
      triangle.setPatternFill({
        source: fillValue,
        repeat: "repeat",
      });
    }

    addShape(triangle);
  };

  const addText = () => {
    const fillValue = fillType === "image" ? createImageFill() : getFillValue();
    const text = new fabric.Textbox("Enter text here", {
      left: 400,
      top: 400,
      fontSize: 20,
      fontFamily: "Arial",
      fill: fillType === "image" ? "" : fillValue,
      stroke: strokeColor,
      strokeWidth: strokeWidth,
      strokeDashArray:
        outlineType === "dashed"
          ? [5, 5]
          : outlineType === "dotted"
          ? [1, strokeWidth * 2]
          : null,
          visible: true, // Initially visible

    });

    if (fillType === "image" && fillValue) {
      text.setPatternFill({
        source: fillValue,
        repeat: "repeat",
      });
    }

    addShape(text);
  };

  const getFillValue = () => {
    switch (fillType) {
      case "solid":
        return fillEnabled ? fillColor : "";
      case "gradient":
        return createGradientFill();
      case "image":
        return createImageFill();
      case "hatch":
        return createHatchFill();
      default:
        return "";
    }
  };

  const createGradientFill = () => {
    const gradient = new fabric.Gradient({
      type: "linear",
      gradientUnits: "pixels",
      coords: { x1: 0, y1: 0, x2: 0, y2: 200 },
      colorStops: [
        { offset: 0, color: gradientStartColor },
        { offset: 1, color: gradientEndColor },
      ],
    });
    return gradient;
  };

  const createImageFill = () => {
    return imageURL;
  };

  const createHatchFill = () => {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    canvas.width = 20;
    canvas.height = 20;

    switch (hatchType) {
      case "diagonal":
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(20, 20);
        ctx.stroke();
        break;
      case "horizontal":
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;

        ctx.beginPath();
        ctx.moveTo(0, 10);
        ctx.lineTo(20, 10);
        ctx.stroke();
        break;
      case "vertical":
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;

        ctx.beginPath();
        ctx.moveTo(10, 0);
        ctx.lineTo(10, 20);
        ctx.stroke();
        break;
      default:
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(20, 20);
        ctx.stroke();
    }

    const pattern = new fabric.Pattern({
      source: canvas,
      repeat: "repeat",
    });

    return pattern;
  };

  const handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      if (file.type.startsWith("image/")) {
        const imageUrl = await loadImageAsDataURL(file);
        setImageURL(imageUrl);
        setFillType("image");
      } else if (file.type === "application/pdf") {
        // Handle PDF upload
      }
    } catch (error) {
      console.error("Error handling image upload:", error);
    }
  };

  const loadImageAsDataURL = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  };

  const clearCanvas = () => {
    if (!canvas) return;
    canvas.clear();
    setShapes([]);
  };

  const deleteSelectedShape = () => {
    const activeObject = canvas.getActiveObject();
    if (activeObject) {
      removeShape(activeObject);
    }
  };

  useEffect(() => {
    canvas?.on("selection:created", () => {
      document.addEventListener("keydown", handleKeyPress);
    });
    canvas?.on("selection:cleared", () => {
      document.removeEventListener("keydown", handleKeyPress);
    });

    return () => {
      document.removeEventListener("keydown", handleKeyPress);
    };
  }, [canvas]);

  const handleKeyPress = (event) => {
    if (event.key === "Delete") {
      deleteSelectedShape();
    } else if (event.key === "d" && event.ctrlKey) {
      const activeObject = canvas.getActiveObject();
    }
  };

  const toggleFreeformDrawing = () => {
    if (!canvas) return;
    canvas.isDrawingMode = !canvas.isDrawingMode;
  };

  const saveAsImage = () => {
    if (!canvas) return;

    const dataURL = canvas.toDataURL({
      format: "jpeg",
      quality: 0.8,
    });

    const link = document.createElement("a");
    link.href = dataURL;
    link.download = "canvas_image.jpg";
    link.click();
  };

  useEffect(() => {
    if (canvas) {
      canvas.on("path:created", (e) => {
        const path = e.path;
        addShape(path);
      });
    }
  }, [canvas]);

  const applyChanges = () => {
    setStrokeColor(tempStrokeColor);
    setStrokeWidth(tempStrokeWidth);
    setFillColor(tempFillColor);
    setOutlineColor(tempOutlineColor);
    setOutlineType(tempOutlineType);

    canvas.forEachObject((object) => {
      if (
        object.type === "rect" ||
        object.type === "circle" ||
        object.type === "triangle" ||
        object.type === "textbox"
      ) {
        object.set({
          stroke: tempStrokeColor,
          strokeWidth: tempStrokeWidth,
          fill: getFillValue(),
          strokeDashArray:
            tempOutlineType === "dashed"
              ? [5, 5]
              : tempOutlineType === "dotted"
              ? [1, 5]
              : null,
        });
        canvas.requestRenderAll();
      }
    });
  };
  useEffect(() => {
    if (drawingPolygon && canvas) {
      canvas.on("mouse:down", handleMouseDown);
    } else {
      if (canvas) {
        canvas.off("mouse:down", handleMouseDown);
      }
    }
  }, [drawingPolygon, canvas]);

  const handleMouseDown = (event) => {
    const pointer = canvas.getPointer(event.e);
    const clickedPoint = new fabric.Point(pointer.x, pointer.y);
    setPoints([...points, clickedPoint]);
  };

  const addPolygon = () => {
    if (!canvas || points.length < 3) return;

    const polygon = new fabric.Polygon(points, {
      fill: fillColor,
      stroke: strokeColor,
      strokeWidth: strokeWidth,
    });

    canvas.add(polygon);
    setPoints([]);
    setDrawingPolygon(false);
  };



  const toggleDrawingPolygon = () => {
    setDrawingPolygon(!drawingPolygon);
  };
  useEffect(() => {
    setTempStrokeColor(strokeColor);
  }, [strokeColor]);

  useEffect(() => {
    setTempStrokeWidth(strokeWidth);
  }, [strokeWidth]);

  useEffect(() => {
    setTempFillColor(fillColor);
  }, [fillColor]);

  useEffect(() => {
    setTempOutlineColor(outlineColor);
  }, [outlineColor]);

  useEffect(() => {
    setTempOutlineType(outlineType);
  }, [outlineType]);

  return (
    <div>
      <div className="mx-8 my-4">
        <button onClick={addRect}>Add Rectangle</button>
        <button onClick={addCircle}>Add Circle</button>
        <button onClick={addTriangle}>Add Triangle</button>
        <button onClick={addText}>Add Text</button>{" "}
        <button onClick={toggleDrawingPolygon}>
          {drawingPolygon ? "Finish Drawing Polygon" : "Draw Polygon"}
        </button>

        <input
          type="checkbox"
          checked={fillEnabled}
          onChange={() => setFillEnabled(!fillEnabled)}
        />{" "}
        <label>Fill</label>
        <input
          type="color"
          value={strokeColor}
          onChange={(e) => setStrokeColor(e.target.value)}
        />
        <input
          type="number"
          value={strokeWidth}
          onChange={(e) => setStrokeWidth(parseInt(e.target.value))}
        />
        <input
          type="color"
          value={fillColor}
          onChange={(e) => setFillColor(e.target.value)}
        />
        <select value={fillType} onChange={(e) => setFillType(e.target.value)}>
          <option value="solid">Solid Color</option>
          <option value="gradient">Gradient</option>
          <option value="image">Image</option>
          <option value="hatch">Hatch</option>
        </select>
        {fillType === "gradient" && (
          <div>
            <input
              type="color"
              value={gradientStartColor}
              onChange={(e) => setGradientStartColor(e.target.value)}
            />
            <input
              type="color"
              value={gradientEndColor}
              onChange={(e) => setGradientEndColor(e.target.value)}
            />
          </div>
        )}
        {fillType === "image" && (
          <input type="file" accept="image/*" onChange={handleImageUpload} />
        )}
        {fillType === "hatch" && (
          <select
            value={hatchType}
            onChange={(e) => setHatchType(e.target.value)}
          >
            <option value="diagonal">Diagonal</option>
            <option value="horizontal">Horizontal</option>
            <option value="vertical">Vertical</option>
          </select>
        )}
        <select
          value={outlineType}
          onChange={(e) => setOutlineType(e.target.value)}
        >
          <option value="solid">Solid</option>
          <option value="dashed">Dashed</option>
          <option value="dotted">Dotted</option>
        </select>
        <button onClick={toggleFreeformDrawing}>Add Freeform Drawing</button>
        <button onClick={clearCanvas}>Clear Canvas</button>
        <button onClick={saveAsImage}>Save as Image</button>
        <button onClick={applyChanges}>Apply</button>
      </div>
      <div className="d-flex gap-4">
        <div className="d-flex flex-column w-30">
          {shapes.map((shape, index) => (
            <div
              key={index}
              style={{ display: "inline-block", margin: "5px" }}
              className={selectedShapeIndex === index ? "active-shape" : ""}
            >
              <img
                src={shape.toDataURL()}
                alt="Shape"
                style={{ width: "20px", height: "20px" }}
                onClick={() => removeShape(shape)}
              />
              <button onClick={() => removeShape(shape)}>Delete</button>
              <button onClick={() => duplicateShape(shape)}>Duplicate</button>
              {/* Add eye icon to toggle visibility */}
              <button className="" onClick={() => toggleShapeVisibility(index)}>
                {shapeVisibility[index] ? "Hide" : "Show"}
              </button>
            </div>
          ))}
        </div>
        <div ref={canvasContainerRef}>
          <canvas id="drawingCanvas"></canvas>
        </div>
      </div>
    </div>
  );
};

export default SideMenus;
