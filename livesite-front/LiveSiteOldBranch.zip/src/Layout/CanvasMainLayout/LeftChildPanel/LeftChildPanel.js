import React, { useState } from "react";
import Layer from "../../../components/Layer";

export default function LeftChildPanel({
  removeShape,
  duplicateShape,
  shapes,
  selectedShapeIndex,
}) {
  const [showOpt, setShowOpt] = useState(false);

  return (
    <>
      <div className="layer-heading d-flex me-auto text-start d-block pb-4">
        Layers
      </div>

      {shapes.map((shape, index) => (
        <div
          key={index}
          className={
            selectedShapeIndex === index
              ? "d-flex mb-2 flex-row justify-content-between align-items-center layer-item cursor-pointer px-4 py-2 gap-4  rounded position-relative w-100 active-shape"
              : "d-flex flex-row justify-content-between align-items-center layer-item cursor-pointer px-4 py-2 gap-4 border rounded position-relative w-100 mb-2"
          }
        >
          <Layer
            showOpt={setShowOpt}
            removeShape={removeShape}
            duplicateShape={duplicateShape}
            shape={shape}
            index={index}
          />
        </div>
      ))}
    </>
  );
}
