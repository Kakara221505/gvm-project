import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import Form from "react-bootstrap/Form";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import del from "../../images/delete.svg";

export default function TopPanel({
  handleImageUpload,
  clearCanvas,
  saveAsImage,
  fillEnabled,
  setFillEnabled,
}) {
  const [showDropdown1, setShowDropdown1] = useState(false);
  const [showDropdown2, setShowDropdown2] = useState(false);

  const handleMouseOver1 = () => {
    setShowDropdown1(true);
  };

  const handleMouseOut1 = () => {
    setShowDropdown1(false);
  };

  const handleMouseOver2 = () => {
    setShowDropdown2(true);
  };

  const handleMouseOut2 = () => {
    setShowDropdown2(false);
  };

  return (
    <Navbar
      expand="lg"
      sticky="top"
      className="bg-transparent shadow-none navbar-styling py-0"
    >
      <Container fluid className="navbar-container-fluid px-0">
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll ">
          <Nav.Link className="navTextFont px-4 ps-1" href="#action1">
            <img
              src="https://static.vecteezy.com/system/resources/previews/010/952/951/non_2x/movie-film-editor-logo-design-video-editing-logo-concept-vector.jpg"
              className="img-fluid"
              height={35}
              width={35}
            />
          </Nav.Link>
          <Nav className="me-auto my-2 my-lg-0" navbarScroll>
            <Nav.Link className="navTextFont px-2 ps-0" href="#action1">
              Home
            </Nav.Link>
            <NavDropdown
              className="navTextFont border-0 rounded-0"
              title="File"
              id="navbarScrollingDropdown1"
              show={showDropdown1}
              onMouseOver={handleMouseOver1}
              onMouseOut={handleMouseOut1}
            >
              <NavDropdown.Item href="#action3" className="navTextFont">
                New Project
              </NavDropdown.Item>
              <NavDropdown.Item href="#action4" className="navTextFont">
                Open
              </NavDropdown.Item>
              {/* <NavDropdown.Divider /> */}
              <NavDropdown.Item href="#action5" className="navTextFont">
                Save
              </NavDropdown.Item>
              <NavDropdown.Item href="#action6" className="navTextFont">
                Save As
              </NavDropdown.Item>
              <NavDropdown.Item href="#action6" className="navTextFont">
                Close
              </NavDropdown.Item>
            </NavDropdown>

            <NavDropdown
              className="navTextFont"
              title="Upload"
              id="navbarScrollingDropdown2"
              show={showDropdown2}
              onMouseOver={handleMouseOver2}
              onMouseOut={handleMouseOut2}
            >
              {/* <NavDropdown.Item href="#action4">Image</NavDropdown.Item> */}
              {/* <NavDropdown.Divider /> */}
              {/* <NavDropdown.Item href="#action5">PDF</NavDropdown.Item> */}

              <NavDropdown.Item href="#action4" className="d-flex flex-column">
                <label for="upload">
                  <span
                    class="navTextFont glyphicon glyphicon-folder-open"
                    aria-hidden="true"
                  >
                    File
                  </span>
                  <input
                    type="file"
                    id="upload"
                    accept="image/*, .pdf"
                    onChange={handleImageUpload}
                    style={{ display: "none" }}
                  />
                </label>
              </NavDropdown.Item>
            </NavDropdown>

            <Nav.Link className="navTextFont px-2" href="#action2">
              Edit
            </Nav.Link>
            <Nav.Link className="navTextFont px-2" href="#action3">
              View
            </Nav.Link>
            <Nav.Link className="navTextFont px-2" href="#action4">
              Help
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
        {/* <div className="d-flex mx-5 align-items-center justify-content-between">
          <div className="">Fill</div>
          <div className="ps-2">
            <Form.Check aria-label="option 1"  onChange={() => setFillEnabled(!fillEnabled)} checked={fillEnabled} />
          </div>

        </div> */}
        <div
          className="d-flex flex-row align-items-center justify-content-end border-0  rounded py-2 clear-canvas-btn"
          onClick={clearCanvas}
        >
          <div className="">
            <img className="img-fluid " height={15} width={15} src={del} />
          </div>
          <div className="navTextFont"></div>
        </div>
        <div
          className="d-flex mx-3 me-1 mt-1 flex-row align-items-center justify-content-end cursor-pointer"
          onClick={saveAsImage}
        >
          <img
            src="https://cdn-icons-png.flaticon.com/512/6324/6324597.png"
            className="img-fluid"
            height={22}
            width={22}
          />
        </div>
      </Container>
    </Navbar>
  );
}
