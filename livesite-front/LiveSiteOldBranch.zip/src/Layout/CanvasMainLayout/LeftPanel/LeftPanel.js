import React from "react";
import "../CanvasMain.css";
import Rect from "../../images/rectangle.svg";
import Triangle from "../../images/triangle.svg";
import Oval from "../../images/ellipse.svg";
import Text from "../../images/text.svg";
import Eraser from "../../images/eraser.svg";

export default function LeftPanel({
  addRect,
  addText,
  addCircle,
  addTriangle,
  toggleFreeformDrawing,
  fileUploaded,
  toggleRightCanvas,
  addPolygon,
  drawPentagon,
  showPolygon,
  editPolygon,
  addStar,
  addOctagon
}) {
  return (
    <>

    
      <div
        className="py-3 d-flex align-items-center justify-content-between cursor-pointer"
        onClick={toggleFreeformDrawing}
      >
        <div className="">
          <img
            className="img-fluid "
            height={20}
            width={20}
            src="https://cdn4.iconfinder.com/data/icons/materia-tools-vol-1/24/023_014_023_pen_ink_classic_retro_tool_freeform-512.png"
          />
        </div>
      </div>
      <div
        className="py-3 d-flex align-items-center justify-content-between cursor-pointer"
        onClick={addRect}
      >
        <div className="">
          <img className="img-fluid " height={20} width={20} src={Rect} />
        </div>
      </div>
      <div
        className="py-3 d-flex align-items-center justify-content-between cursor-pointer"
        onClick={addTriangle}
      >
        <div className="">
          <img className="img-fluid " height={20} width={20} src={Triangle} />
        </div>
      </div>
      <div
        className="py-3 d-flex align-items-center justify-content-between cursor-pointer"
        onClick={addCircle}
      >
        <div className="">
          <img className="img-fluid " height={20} width={20} src={Oval} />
        </div>
      </div>
      <div
        className="py-3 d-flex align-items-center justify-content-between cursor-pointer"
        onClick={drawPentagon}
      >
        <div className="">
          <img className="img-fluid " height={20} width={20} src='https://cdn-icons-png.flaticon.com/512/7168/7168063.png' />
        </div>
      </div>

      <div
        className="py-3 d-flex align-items-center justify-content-between cursor-pointer"
        onClick={addStar}
      >
        <div className="">
          <img className="img-fluid " height={20} width={20} src='https://cdn-icons-png.flaticon.com/512/929/929566.png' />
        </div>
      </div>

      <div
        className="py-3 d-flex align-items-center justify-content-between cursor-pointer"
        onClick={addOctagon}
      >
        <div className="">
          <img className="img-fluid " height={20} width={20} src='https://cdn.iconscout.com/icon/free/png-256/free-octagon-3603640-3004662.png' />
        </div>
      </div>

      <div
        className="py-3 d-flex align-items-center justify-content-between cursor-pointer"
        onClick={addText}
      >
        <div className="">
          <img className="img-fluid " height={20} width={20} src={Text} />
        </div>
      </div>
      {/* https://cdn.iconscout.com/icon/free/png-256/free-layer-3660964-3095384.png */}
      <div className="py-3 d-flex align-items-center justify-content-between cursor-pointer">
        <div className="">
          <img className="img-fluid " height={20} width={20} src={Eraser} />
        </div>
      </div>
    </>
  );
}
