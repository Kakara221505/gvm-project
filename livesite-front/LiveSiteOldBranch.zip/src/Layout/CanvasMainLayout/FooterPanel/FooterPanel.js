import React from "react";
import del from "../../images/delete.svg";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";

export default function FooterPanel({fillEnabled, setFillEnabled}) {
  return (
    <>
      <div className="col-lg-8 d-flex align-items-center justify-content-center">
        Footer
        {/* <div className="d-flex flex-column align-items-center justify-content-center" onClick={clearCanvas}>
          <div className="mb-3">
            <img className="img-fluid " height={25} width={25} src={del} />
          </div>
          <div className="" >Clear Canvas</div>
        </div> */}
        {/* <div className="d-flex mx-5 align-items-center justify-content-between">
          <div className="">Fill</div>
          <div className="ps-2">
            <Form.Check aria-label="option 1"  onChange={() => setFillEnabled(!fillEnabled)} checked={fillEnabled} />
          </div>

        </div> */}
        {/* <div className="d-flex mx-4 flex-column align-items-center justify-content-between" onClick={saveAsImage}>
          <div className="">
            <Button variant="primary">Save as Image</Button>{" "}
          </div>
        </div> */}
      </div>
    </>
  );
}
