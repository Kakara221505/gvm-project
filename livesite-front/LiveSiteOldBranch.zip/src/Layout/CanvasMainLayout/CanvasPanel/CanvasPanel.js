import React, { useState } from 'react'
import CustomMenu from '../../../components/CustomMenu';

export default function CanvasPanel({canvasContainerRef, onContextMenu}) {
     console.log("Canvas", canvasContainerRef);
  return (
    <div>

 
    <div ref={canvasContainerRef}>
          <canvas id="drawingCanvas"   onContextMenu={(e) => onContextMenu(e)}></canvas>
        </div>


   </div>
  )
}
