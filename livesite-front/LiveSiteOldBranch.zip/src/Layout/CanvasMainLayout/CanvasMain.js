import React, { useState, useEffect } from "react";
import { Offcanvas } from "react-bootstrap";
import "./CanvasMain.css";
import TopPanel from "./TopPanel/TopPanel";
import LeftPanel from "./LeftPanel/LeftPanel";
import LeftChildPanel from "./LeftChildPanel/LeftChildPanel";
import FooterPanel from "./FooterPanel/FooterPanel";
import CanvasPanel from "./CanvasPanel/CanvasPanel";
import RightPanel from "./RightPanel/RightPanel";

export default function CanvasMain({ props }) {
  const {
    showRightCanvas,
    setShowRightCanvas,
    // Other props...
  } = props;
  const [isRightPanelHidden, setIsRightPanelHidden] = useState(
    !showRightCanvas
  );

  const { selectedShapeIndex } = props;
  useEffect(() => {
    setIsRightPanelHidden(showRightCanvas);
  }, [showRightCanvas]);

  const toggleRightPanel = () => {

        setIsRightPanelHidden(!isRightPanelHidden);
  };

  useEffect(() => {
    // Check if a shape is selected, then show the right panel
    if (selectedShapeIndex !== null) {
      setShowRightCanvas(true);
    }
  }, [selectedShapeIndex, setShowRightCanvas]);

  return (
    <>
      <div className="container-fluid px-0 ">
        <div className="mx-0 row">
          <div className="border-bottom border-1  boxShadowBgContainer col-lg-12 rounded-0">
            <TopPanel
              handleImageUpload={props.handleImageUpload}
              fileUploaded={props.fileUploaded}
              clearCanvas={props.clearCanvas}
              saveAsImage={props.saveAsImage}
              fillEnabled={props.fillEnabled}
              setFillEnabled={props.setFillEnabled}
            />
          </div>
        </div>
        <div className="row d-flex mx-0  canvasContainerImg">
          <div className="boxShadowBgContainer border-top rounded-0 col-lg-1 w-auto LeftPanel py-1">
            <LeftPanel
              drawPentagon={props.drawPentagon}
              showPolygon={props.showPolygon}
              editPolygon={props.editPolygon}
              addText={props.addText}
              addPolygon={props.addPolygon}
              addRect={props.addRect}
              addStar={props.addStar}
              addOctagon={props.addOctagon}
              addCircle={props.addCircle}
              addTriangle={props.addTriangle}
              toggleFreeformDrawing={props.toggleFreeformDrawing}
              fileUploaded={props.fileUploaded}
              toggleRightCanvas={props.toggleRightCanvas}
              showRightCanvas={props.showRightCanvas}
              setShowRightCanvas={props.setShowRightCanvas}
            />
          </div>
          <div className="col-lg-9  d-flex justify-content-end align-items-center">
            <CanvasPanel
              className="canvasShadow"
              canvasContainerRef={props.canvasContainerRef}
            />
          </div>
          {isRightPanelHidden && (
            <div className="col-lg-2 position-relative rounded-0 px-0 boxShadowBgContainer d-flex ms-auto right-panel ">
              <div className="me-0 d-flex justify-content-center align-items-baseline">
                <RightPanel
                  fillEnabled={props.fillEnabled}
                  setFillEnabled={props.setFillEnabled}
                  fillType={props.fillType}
                  setFillType={props.setFillType}
                  strokeColor={props.strokeColor}
                  setStrokeColor={props.setStrokeColor}
                  strokeWidth={props.strokeWidth}
                  setStrokeWidth={props.setStrokeWidth}
                  fillColor={props.fillColor}
                  setFillColor={props.setFillColor}
                  gradientStartColor={props.gradientStartColor}
                  setGradientStartColor={props.setGradientStartColor}
                  gradientEndColor={props.gradientEndColor}
                  setGradientEndColor={props.setGradientEndColor}
                  selectedShapeIndex={props.selectedShapeIndex}
                  imageURL={props.imageURL}
                  setImageURL={props.setImageURL}
                  toggleShapeVisibility={props.toggleShapeVisibility}
                  outlineColor={props.outlineColor}
                  setOutlineColor={props.setOutlineColor}
                  outlineType={props.outlineType}
                  setOutlineType={props.setOutlineType}
                  hatchType={props.hatchType}
                  setHatchType={props.setHatchType}
                  applyChanges={props.applyChanges}
                  handleColorChange={props.handleColorChange}
                  handleFontStyleChange={props.handleFontStyleChange}
                  handleCheckboxChange={props.handleCheckboxChange}
                  fontSize={props.fontSize}
                  setFontSize={props.setFontSize}
                  handleFontSizeChange={props.handleFontSizeChange}
                  // selectedShapeIndex={props.selectedShapeIndex}
                  removeShape={props.removeShape}
                  duplicateShape={props.duplicateShape}
                  shapes={props.shapes}
                  shapeVisibility={props.shapeVisibility}
                  setShapeVisibility={props.setShapeVisibility}
                  // toggleShapeVisibility={props.toggleShapeVisibility}
                  toggleRightPanel={toggleRightPanel}
                  setRightClickSelected={props.setRightClickSelected}
                  addComment={props.addComment}
                  fontColor={props.fontColor}
                  setFontColor={props.setFontColor}
                  linethrough={props.linethrough}
                   setLineThrough={props.setLineThrough}
                  overline ={props.overline}
                  setOverLine={props.setOverLine}
                  isItalic ={props.isItalic}
                  setIsItalic={props.setIsItalic}
                  isUnderline ={props.isUnderline}
                  setIsUnderline={props.setIsUnderline}
                  isBold ={props.isBold}
                  setIsBold={props.setIsBold}
                  textAlign ={props.textAlign}
                  setTextAlign={props.setTextAlign}
                  fontFamily ={props.fontFamily}
                  setFontFamily={props.setFontFamily}
                />
              </div>
            </div>
          )}
        </div>
        {/* Toggle button for RightPanel */}
        {!isRightPanelHidden && (
          <div
            id="toggle"
            className={`neumorphic d-flex align-items-center justify-content-center ${
              isRightPanelHidden ? "hide" : ""
            }`}
            onClick={toggleRightPanel}
          >
            <img
              className="img-fluid"
              height={25}
              width={25}
              src="https://cdn.iconscout.com/icon/free/png-256/free-layer-3660964-3095384.png"
            />
          </div>
        )}
      </div>
    </>
  );
}
