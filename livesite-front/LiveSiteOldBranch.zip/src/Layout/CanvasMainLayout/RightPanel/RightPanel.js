import React, { useState, useEffect } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Layer from "../../../components/Layer";

export default function RightPanel({
  fillType,
  setFillType,
  fillEnabled,
  setFillEnabled,
  strokeColor,
  setStrokeColor,
  strokeWidth,
  setStrokeWidth,
  outlineType,
  setOutlineType,
  applyChanges,
  fillColor,
  setFillColor,
  gradientStartColor,
  setGradientStartColor,
  gradientEndColor,
  setGradientEndColor,
  hatchType,
  setHatchType,
  removeShape,
  duplicateShape,
  shapes,
  selectedShapeIndex,
  toggleRightPanel,
  shapeVisibility,
  toggleShapeVisibility,
  setShapeVisibility,
  addComment,
  setRightClickSelected,
  handleCheckboxChange,
  handleFontStyleChange,
  handleColorChange,
  fontSize,
  handleFontSizeChange,
  setFontColor,
  fontColor,
  setFontSize,
  linethrough, setLineThrough,
overline,setOverLine,
isItalic,setIsItalic,
isUnderline,setIsUnderline,
isBold,setIsBold,
textAlign,setTextAlign,
fontFamily,setFontFamily,
}) {
  // const [fillType, setFillType] = useState("solid");
  const [showOpt, setShowOpt] = useState(false);
  const [currActiveOpt, setCurrentActiveOpt] = useState();

  const onCloseSide = () => {
    // toggleRightPanel
  };
  console.log(
    "SELECTED SHAPE INDEX",
    selectedShapeIndex,
    shapes[selectedShapeIndex]?.text
  );

  useEffect(() => {
    console.log("first", toggleRightPanel);
  }, []);

  return (
    <>
      <div className="d-flex flex-column">
        <div className="row mx-0 ">
          <div className="border-bottom px-3 d-flex justify-content-between align-items-center py-1">
            <h5 className="mb-0 layer-heading d-flex me-auto text-start fw-normal d-block py-2 ">
              Property Explorer
            </h5>
            <div className="cursor-pointer" onClick={toggleRightPanel}>
              <img
                src="https://t3.ftcdn.net/jpg/03/64/30/82/360_F_364308273_cV9OrZrqUpZ8En9rC8KxBqaxkVg95ZTY.jpg"
                height={20}
                width={20}
                className="img-fluid"
              />
            </div>
          </div>

          <div className="propertySectionFill px-3 my-3 mb-0">
            {(selectedShapeIndex === null || selectedShapeIndex === -1) && (
              <div>No Shape Selected.</div>
            )}

            {selectedShapeIndex !== null &&
              selectedShapeIndex !== -1 &&
              shapes[selectedShapeIndex]?.text === undefined && (
                <>
                  <h6 className="my-3 mb-2 fw-medium">Fill Settings</h6>
                  <div className="d-flex align-items-baseline">
                    <div className="col-lg-4 d-flex align-items-center">
                      <label className="mb-0 fs-6 fw-normal">Fill</label>
                      <div className="ps-2">
                        <Form.Check
                          aria-label="option 1"
                          onChange={() => setFillEnabled(!fillEnabled)}
                          checked={fillEnabled}
                        />
                      </div>
                    </div>

                    {fillEnabled && ( // Conditionally render the dropdown based on the state of fillEnabled
                      <>
                        <div className="d-flex flex-column justify-content-between">
                          <div className="col-lg-12">
                            <div className="">
                              <Form.Select
                                aria-label="Default Form.Select example"
                                value={fillType}
                                onChange={(e) => setFillType(e.target.value)}
                              >
                                <option value="solid">Solid Color</option>
                                <option value="gradient">Gradient</option>
                                <option value="image">Image</option>
                                <option value="hatch">Hatch</option>
                              </Form.Select>
                            </div>
                          </div>
                          <div className="col-lg-12">
                            {selectedShapeIndex !== null &&
                              selectedShapeIndex !== -1 &&
                              fillType === "solid" && (
                                <div className="d-flex my-3">
                                  <div className="col-lg-12 d-flex align-items-center">
                                    <input
                                      className="w-100"
                                      type="color"
                                      value={fillColor}
                                      onChange={(e) =>
                                        setFillColor(e.target.value)
                                      }
                                    />
                                  </div>
                                </div>
                              )}
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </>
              )}

            {/* Conditional rendering based on fill type */}

            {selectedShapeIndex !== null &&
              selectedShapeIndex !== -1 &&
              shapes[selectedShapeIndex]?.text === undefined &&
              fillType === "gradient" && (
                <div className="d-flex my-3">
                  <div className="col-lg-6">
                    <div className="d-flex align-items-center">
                      <label htmlFor="gradient1" className="me-3 fs-6">
                        Gradient
                      </label>
                      <input
                        type="color"
                        value={gradientStartColor}
                        onChange={(e) => setGradientStartColor(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="col-lg-6 d-flex justify-content-center">
                    <div>
                      <input
                        type="color"
                        value={gradientEndColor}
                        onChange={(e) => setGradientEndColor(e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              )}

            {selectedShapeIndex !== null &&
              selectedShapeIndex !== -1 &&
              shapes[selectedShapeIndex]?.text === undefined &&
              fillType === "hatch" && (
                <div className="d-flex align-items-baseline my-3">
                  <div className="col-lg-12">
                    <div className="">
                      <Form.Select
                        value={hatchType}
                        onChange={(e) => setHatchType(e.target.value)}
                        aria-label="Default Form.Select example"
                      >
                        <option>Select Hatch</option>
                        <option value="diagonal">Diagonal</option>
                        <option value="horizontal">Horizontal</option>
                        <option value="vertical">Vertical</option>
                      </Form.Select>
                    </div>
                  </div>
                </div>
              )}
          </div>

          <div className="propertySectionStroke px-3">
            {selectedShapeIndex !== null &&
              selectedShapeIndex !== -1 &&
              shapes[selectedShapeIndex]?.text === undefined && (
                <>
                  <h6 className="my-3 mt-1 fw-medium">Stroke Settings</h6>
                  <div className="d-flex align-items-baseline">
                    <div className="col-lg-12 d-flex align-items-center">
                      <div className="col-lg-6">
                        <label
                          htmlFor="solidColor"
                          className="fw-normal fs-6  mb-3"
                        >
                          Stroke Width
                        </label>
                      </div>
                      <div className="col-lg-6 ps-2">
                        <Form.Group
                          className="mb-3"
                          controlId="exampleForm.ControlInput1"
                        >
                          <Form.Control
                            type="number"
                            value={strokeWidth}
                            onChange={(e) =>
                              setStrokeWidth(parseInt(e.target.value))
                            }
                          />
                        </Form.Group>
                      </div>
                    </div>
                  </div>
                </>
              )}

            {selectedShapeIndex !== null &&
              selectedShapeIndex !== -1 &&
              shapes[selectedShapeIndex]?.text === undefined && (
                <div className="d-flex align-items-center">
                  <div className="col-lg-6 ">
                    <label htmlFor="solidColor" className="fs-6">
                      Stroke Type
                    </label>
                  </div>
                  <div className="col-lg-6">
                    <Form.Select
                      value={outlineType}
                      onChange={(e) => setOutlineType(e.target.value)}
                      aria-label="Default Form.Select example"
                    >
                      <option value="solid">Solid</option>
                      <option value="dashed">Dashed</option>
                      <option value="dotted">Dotted</option>
                    </Form.Select>
                  </div>
                </div>
              )}

            {selectedShapeIndex !== null &&
              selectedShapeIndex !== -1 &&
              shapes[selectedShapeIndex]?.text === undefined && (
                <div className="d-flex align-items-center">
                  <div className="col-lg-6 ">
                    <label htmlFor="solidColor" className="fs-6">
                      Stroke Color
                    </label>
                  </div>
                  <div className="col-lg-6 my-3">
                    <input
                      className="w-100"
                      type="color"
                      value={strokeColor}
                      onChange={(e) => setStrokeColor(e.target.value)}
                    />
                  </div>
                </div>
              )}

            {selectedShapeIndex !== null &&
              selectedShapeIndex !== -1 &&
              shapes[selectedShapeIndex]?.text === undefined && (
                <div className="d-flex justify-content-end">
                  <Button variant="primary" onClick={applyChanges}>
                    Apply
                  </Button>{" "}
                </div>
              )}
          </div>

          <div className="propertySectionStroke px-3">
            {selectedShapeIndex !== null &&
              selectedShapeIndex !== -1 &&
              shapes[selectedShapeIndex]?.text !== undefined && (
                <>
                  <div className="d-flex align-items-center">
                    <div className="col-lg-12">
                      <label htmlFor="solidColor" className="py-2 fs-6">
                        Text Properties
                      </label>
                    </div>
                  </div>
                  <div className="col-lg-12">
                    <div id="text-wrapper" style={{ marginTop: "10px" }}>
                      {/* Text controls */}
                      <div id="text-controls">
                        {/* Color picker */}

                        <div className="row">
                          <div className="col-lg-6">
                            <label
                              htmlFor="font-family"
                              style={{ display: "inline-block" }}
                            >
                              Font Color
                            </label>
                            <br />
                            <input
                              type="color"
                              value={fontColor}
                              onChange={(e) =>
                                { 
                                  setFontColor(e.target.value)
                                  handleColorChange("fill", e.target.value)
                                }
                              }
                              size="10"
                            />
                          </div>
                          <div className="col-lg-6">
                            <label
                              htmlFor="font-family"
                              style={{ display: "inline-block" }}
                            >
                              Font family
                            </label>
                            <Form.Select
                              id="font-family"
                              value={fontFamily}
                              onChange={(e) =>{
                                setFontFamily(e.target.value)
                                handleFontStyleChange(
                                  "fontFamily",
                                  e.target.value
                                )
                              }
                              }
                            >
                              <option value="arial">Arial</option>
                              <option value="helvetica" selected>
                                Helvetica
                              </option>
                              <option value="myriad pro">Myriad Pro</option>
                              <option value="delicious">Delicious</option>
                              <option value="verdana">Verdana</option>
                              <option value="georgia">Georgia</option>
                              <option value="courier">Courier</option>
                              <option value="comic sans ms">
                                Comic Sans MS
                              </option>
                              <option value="impact">Impact</option>
                              <option value="monaco">Monaco</option>
                              <option value="optima">Optima</option>
                              <option value="hoefler text">Hoefler Text</option>
                              <option value="plaster">Plaster</option>
                              <option value="engagement">Engagement</option>
                            </Form.Select>
                          </div>
                        </div>
                        <div className="row my-2">
                          <div className="col-lg-6">
                            <label
                              htmlFor="text-align"
                              style={{ display: "inline-block" }}
                            >
                              Font Size
                            </label>

                            <Form.Control
                              type="text"
                              value={fontSize}
                              onChange={(e) =>{
                              
                                handleFontSizeChange(e.target.value)
                              }
                              }
                            />
                          </div>
                          <div className="col-lg-6">
                            <label
                              htmlFor="text-align"
                              style={{ display: "inline-block" }}
                            >
                              Text align
                            </label>
                            <Form.Select
                              id="text-align"
                              value={textAlign}
                              onChange={(e) =>{
                                setTextAlign(e.target.value)
                                handleFontStyleChange(
                                  "textAlign",
                                  e.target.value
                                )
                              }
                              }
                            >
                              <option value="left">Left</option>
                              <option value="center">Center</option>
                              <option value="right">Right</option>
                              <option value="justify">Justify</option>
                            </Form.Select>
                          </div>
                        </div>

                        {/* <div className="row">
                          <div className="col-lg-12">
                          <Form.Label>Line Height</Form.Label>
                          <Form.Range min="0" max="10" step="0.1" id="text-line-height" onChange={(e) => handleFontStyleChange('lineHeight', parseFloat(e.target.value))} />

                          <input type="range" value="" min="0" max="10" step="0.1" id="text-line-height" onChange={(e) => handleFontStyleChange('lineHeight', parseFloat(e.target.value))} />
                          </div>
                        </div> */}

                        <br />
                        {/* Additional controls */}

                        {/* Other controls */}
                        {/* ... */}
                      </div>
                      <div id="text-controls-additional">
                        <div className="row">
                          <div className="col-lg-4">
                            <Form.Check // prettier-ignore
                             checked={isBold}
                              onChange={(e) =>{
                                setIsBold(true)
                                handleCheckboxChange(
                                  "fontWeight",
                                  e.target.checked ? "bold" : ""
                                )
                              }
                              }
                              type="checkbox"
                              id="text-cmd-bold"
                              label="Bold"
                            />
                          </div>
                          <div className="col-lg-4">
                            <Form.Check // prettier-ignore
                               checked={isUnderline}
                              onChange={(e) =>{
                                setIsUnderline(e.target.checked)
                                handleCheckboxChange(
                                  "underline",
                                  e.target.checked ? "underline" : ""
                                )
                              }
                              }
                              type="checkbox"
                              id="text-cmd-underline"
                              label="Underline"
                            />
                          </div>
                          <div className="col-lg-4">
                            <Form.Check // prettier-ignore
                            checked={isItalic}
                              onChange={(e) =>{
                                setIsItalic(e.target.checked)
                                handleCheckboxChange(
                                  "fontStyle",
                                  e.target.checked ? "italic" : ""
                                )
                              }
                              }
                              type="checkbox"
                              id="text-cmd-italic"
                              label="Italic"
                            />
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-lg-4">
                            <Form.Check // prettier-ignore
                            checked={overline}
                              onChange={(e) =>{
                                setOverLine(e.target.checked)
                                handleCheckboxChange(
                                  "overline",
                                  e.target.checked ? "overline" : ""
                                )
                              }
                              }
                              type="checkbox"
                              id="text-cmd-overline"
                              label="Overline"
                            />
                          </div>
                          <div className="col-lg-4">
                            <Form.Check // prettier-ignore
                            checked={linethrough}
                              onChange={(e) =>{
                                setLineThrough(e.target.checked)
                                handleCheckboxChange(
                                  "linethrough",
                                  e.target.checked ? "linethrough" : ""
                                )
                              }
                              }
                              type="checkbox"
                              id="text-cmd-linethrough"
                              label="Linethrough"
                            />
                          </div>
                        </div>

                        <div className="row my-4 mb-0">
                         {/* <div className="col-lg-12 d-flex ms-auto justify-content-end">
                            <Button variant="primary" onClick={applyChanges}>
                              Apply
                            </Button>{" "}
                          </div> */}
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}
          </div>
          <div className="border-bottom border-top mt-3 px-3 mb-3">
            <h5 className="mb-0 layer-heading d-flex me-auto text-start fw-normal d-block py-2">
              Layers
            </h5>
          </div>
          <div className="layerChipContainer position-relative">
            {shapes.length === 0 ? (
              <p className="">No layers available</p>
            ) : (
              shapes.map((shape, index) => (
                <div
                  key={index}
                  className={
                    selectedShapeIndex === index
                      ? "d-flex mb-2 flex-row justify-content-between align-items-center layer-item cursor-pointer px-4 py-2 gap-4  rounded position-relative m-auto active-shape"
                      : "d-flex flex-row justify-content-between align-items-center layer-item cursor-pointer px-4 py-2 gap-4 border rounded position-relative  mb-2"
                  }
                >
                  <Layer
                    showOpt={setShowOpt}
                    setCurrentActiveOpt={setCurrentActiveOpt}
                    currActiveOpt={currActiveOpt}
                    removeShape={removeShape}
                    duplicateShape={duplicateShape}
                    shapeVisibility={shapeVisibility}
                    toggleShapeVisibility={toggleShapeVisibility} // Ensure this prop is passed
                    setShapeVisibility={setShapeVisibility}
                    shape={shape}
                    index={index}
                    addComment={addComment}
                    setRightClickSelected={setRightClickSelected}
                  />
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </>
  );
}
