import React, { useState, useRef, useEffect } from "react";
import { fabric } from "fabric";
import { pdfjs } from "react-pdf";

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

const SideMenu = () => {
  const [canvas, setCanvas] = useState(null);
  const [shapes, setShapes] = useState([]);
  const [eraserMode, setEraserMode] = useState(false); // State to control eraser mode
  const [fillEnabled, setFillEnabled] = useState(false); // State to control fill
  const canvasContainerRef = useRef(null);
  const freeformPath = useRef(null);



console.log("SDFDS", canvasContainerRef);
  useEffect(() => {
    const newCanvas = new fabric.Canvas("drawingCanvas", {
      backgroundColor: "#fff",
      width: 800,
      height: 600,
    });
    setCanvas(newCanvas);
  }, []);

  useEffect(() => {
    if (canvas) {
      canvas.isDrawingMode = false;
    }
  }, [canvas]);

  const toggleEraserMode = () => {
    setEraserMode(!eraserMode);
    if (!canvas) return;
    canvas.isDrawingMode = false;
    canvas.freeDrawingBrush = eraserMode ? null : new fabric.PencilBrush(canvas);
    canvas.isDrawingMode = eraserMode;
  };

  const addShape = (shape) => {
    if (!canvas) return;
    if (canvas.isDrawingMode) {
      canvas.isDrawingMode = false;
    }
    canvas.add(shape);
    setShapes([...shapes, shape]);
  };

  const removeShape = (shape) => {
    if (!canvas) return;
    canvas.remove(shape);
    setShapes(shapes.filter((item) => item !== shape));
  };

  const duplicateShape = (shape) => {
    const clonedObject = fabric.util.object.clone(shape);

    clonedObject.set({
      left: shape.left + 10,
      top: shape.top + 10,
    });
    addShape(clonedObject);
  };

  const addRect = () => {
    const rect = new fabric.Rect({
      left: 100,
      top: 100,
      width: 100,
      height: 100,
      fill: fillEnabled ? "red" : "",
      stroke: "black", // Add stroke
      strokeWidth: 2, // Stroke width
    });
    addShape(rect);
  };

  const addCircle = () => {
    const circle = new fabric.Circle({
      left: 200,
      top: 200,
      radius: 50,
      fill: fillEnabled ? "blue" : "",
      stroke: "black", // Add stroke
      strokeWidth: 2, // Stroke width
    });
    addShape(circle);
  };

  const addTriangle = () => {
    const triangle = new fabric.Triangle({
      left: 300,
      top: 300,
      width: 100,
      height: 100,
      fill: fillEnabled ? "green" : "",
      stroke: "black", // Add stroke
      strokeWidth: 2, // Stroke width
    });
    addShape(triangle);
  };

  const addText = () => {
    const text = new fabric.Textbox("Enter text here", {
      left: 400,
      top: 400,
      fontSize: 20,
      fontFamily: "Arial",
      fill: fillEnabled ? "black" : "",
      stroke: "black", // Add stroke
      strokeWidth: 1, // Stroke width
    });
    addShape(text);
  };

  const addImageToCanvas = (imageUrl) => {
    fabric.Image.fromURL(imageUrl, (img) => {
      img.scaleToWidth(canvas.width / 2);
      addShape(img);
    });
  };

  const handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      if (file.type.startsWith("image/")) {
        const imageUrl = await loadImageAsDataURL(file);
        addImageToCanvas(imageUrl);
      } else if (file.type === "application/pdf") {
        const reader = new FileReader();
        reader.onload = async (event) => {
          const typedArray = new Uint8Array(event.target.result);
          const pdfData = typedArray.buffer;

          const pdfDoc = await pdfjs.getDocument({ data: pdfData }).promise;
          const pdfPage = await pdfDoc.getPage(1); 

          const viewport = pdfPage.getViewport({ scale: 1 });
          const canvasElement = document.createElement("canvas");
          const context = canvasElement.getContext("2d");
          canvasElement.width = viewport.width;
          canvasElement.height = viewport.height;

          await pdfPage.render({ canvasContext: context, viewport }).promise;

          const imageUrl = canvasElement.toDataURL("image/jpeg");
          addImageToCanvas(imageUrl);
        };
        reader.readAsArrayBuffer(file);
      }
    } catch (error) {
      console.error("Error handling image upload:", error);
    }
  };

  const loadImageAsDataURL = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  };

  const clearCanvas = () => {
    if (!canvas) return;
    canvas.clear();
    setShapes([]);
  };

  const deleteSelectedShape = () => {
    const activeObject = canvas.getActiveObject();
    if (activeObject) {
      removeShape(activeObject);
    }
  };

  useEffect(() => {
    canvas?.on("selection:created", () => {
      document.addEventListener("keydown", handleKeyPress);
    });
    canvas?.on("selection:cleared", () => {
      document.removeEventListener("keydown", handleKeyPress);
    });

    return () => {
      document.removeEventListener("keydown", handleKeyPress);
    };
  }, [canvas]);

  const handleKeyPress = (event) => {
    if (event.key === "Delete") {
      deleteSelectedShape();
    } else if (event.key === "d" && event.ctrlKey) {
      const activeObject = canvas.getActiveObject();
      if (activeObject) {
        duplicateShape(activeObject);
      }
    }
  };

  const toggleFreeformDrawing = () => {
    if (!canvas) return;
    canvas.isDrawingMode = !canvas.isDrawingMode;
  };

  const saveAsImage = () => {
    if (!canvas) return;

    const dataURL = canvas.toDataURL({
      format: "jpeg",
      quality: 0.8, // Adjust quality as needed
    });

    // Create a temporary anchor element to trigger download
    const link = document.createElement("a");
    link.href = dataURL;
    link.download = "canvas_image.jpg";
    link.click();
  };

  useEffect(() => {
    if (canvas) {
      canvas.on("path:created", (e) => {
        const path = e.path;
        addShape(path);
      });
    }
  }, [canvas]);

  return (
    <div>
      <div>
        <button onClick={addRect}>Add Rectangle</button>
        <button onClick={addCircle}>Add Circle</button>
        <button onClick={addTriangle}>Add Triangle</button>
        <button onClick={addText}>Add Text</button>{" "}
        <input
          type="checkbox"
          checked={fillEnabled}
          onChange={() => setFillEnabled(!fillEnabled)}
        />{" "}
        {/* Checkbox to toggle fill */}
        <label>Fill</label>
        <button onClick={toggleFreeformDrawing}>Add Freeform Drawing</button>
        <input
          type="file"
          accept="image/*, .pdf"
          onChange={handleImageUpload}
        />
        <button onClick={toggleEraserMode}>
          {eraserMode ? "Exit Eraser Mode" : "Enter Eraser Mode"}
        </button>
        <button onClick={clearCanvas}>Clear Canvas</button>
        <button onClick={saveAsImage}>Save as Image</button>

      </div>
      <div>
        {shapes.map((shape, index) => (
          <div key={index} style={{ display: "inline-block", margin: "5px" }}>
            <img
              src={shape.toDataURL()} // Assuming shape.toDataURL() returns image URL
              alt="Shape"
              style={{ width: "50px", height: "50px" }}
              onClick={() => removeShape(shape)}
            />
            <button onClick={() => removeShape(shape)}>Delete</button>
            <button onClick={() => duplicateShape(shape)}>Duplicate</button>
          </div>
        ))}
      </div>
      <div ref={canvasContainerRef}>
        <canvas id="drawingCanvas"></canvas>
      </div>
    </div>
  );
};

export default SideMenu;
