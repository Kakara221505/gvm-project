// import React from 'react';
import CanvasMain from "./Layout/CanvasMainLayout/CanvasMain";
import _debounce from "lodash/debounce";

import SideMenus from "./Layout/SideMenus/SideMenus";
import React, { useState, useRef, useEffect } from "react";
import { fabric } from "fabric";
import { pdfjs } from "react-pdf";
import CustomMenu from "./components/CustomMenu";

const App = () => {
  const defaultRectShapeValue = {
    left: 100,
    top: 100,
    width: 100,
    height: 100,
    fill: "",
    stroke: "#000000",
    strokeWidth: 2,
    strokeDashArray: null,
    strokeUniform: true,
    visible: true, // Initially visible
  };

  const defaultTriangleShapeValue = {
    left: 300,
    top: 300,
    width: 100,
    height: 100,
    fill: "",
    stroke: "#000",
    strokeWidth: 2,
    strokeDashArray: null,
    strokeUniform: true,
    visible: true, // Initially visible
  };

  const defaultCircleShapeValue = {
    left: 200,
    top: 200,
    radius: 50,
    fill: "",
    stroke: "#000",
    strokeWidth: 2,
    strokeDashArray: null,
    strokeUniform: true,
    visible: true, // Initially visible
  };

  const defaultTextValue = {
    left: 400,
    top: 400,
    fontSize: 20,
    fontFamily: "Arial",
    strokeWidth: 0,
    stroke: "#000",
    fill: "#333",
    strokeDashArray: null,
    strokeUniform: true,
    visible: true, // Initially visible
  };

  const defaultPolygonShapeValue = {
    points: [
      { x: 200, y: 10 },
      { x: 250, y: 50 },
      { x: 250, y: 180 },
      { x: 150, y: 180 },
      { x: 150, y: 50 },
    ],
    fill: "",
    stroke: "#000000",
    strokeWidth: 2,
    strokeUniform: true,
    strokeDashArray: null,
    visible: true, // Initially visible
  };

  const defaultStarShapeValue = {
    //  starPoints : [
    //   { x: 0, y: -50 },
    //   { x: 15, y: -15 },
    //   { x: 50, y: 0 },
    //   { x: 15, y: 15 },
    //   { x: 0, y: 50 },
    //   { x: -15, y: 15 },
    //   { x: -50, y: 0 },
    //   { x: -15, y: -15 },
    // ],
    left: 100,
    top: 100,
    fill: "",
    stroke: "#000000",
    strokeWidth: 2,
    strokeUniform: true,
    strokeDashArray: null,
    visible: true, // Initially visible
  };

  const defaultOctagonShapeValue = {
    //  octagonPoints : [
    //   { x: -50, y: 0 },
    //   { x: -35, y: -35 },
    //   { x: 0, y: -50 },
    //   { x: 35, y: -35 },
    //   { x: 50, y: 0 },
    //   { x: 35, y: 35 },
    //   { x: 0, y: 50 },
    //   { x: -35, y: 35 },
    // ],
    left: 100,
    top: 100,
    fill: "",
    stroke: "#000000",
    strokeWidth: 2,
    strokeUniform: true,
    strokeDashArray: null,
    visible: true, // Initially visible
  };

  const [shapeVisibility, setShapeVisibility] = useState([]);
  const [polygonPoints, setPolygonPoints] = useState([]); // State to store the points of the polygon being drawn
  const [canvas, setCanvas] = useState(null);
  const [shapes, setShapes] = useState([]);
  const [eraserMode, setEraserMode] = useState(false);
  const [fillEnabled, setFillEnabled] = useState(false);
  const canvasContainerRef = useRef(null);
  const freeformPath = useRef(null);
  const [selectedShapeIndex, setSelectedShapeIndex] = useState(null); // New state to track selected shape
  const [fileUploaded, setFileUploaded] = useState(false);
  const [fillType, setFillType] = useState("solid");
  const [strokeColor, setStrokeColor] = useState("#000000");
  const [strokeWidth, setStrokeWidth] = useState(2);
  const [fillColor, setFillColor] = useState("#ffffff");
  const [gradientStartColor, setGradientStartColor] = useState("#ffffff");
  const [gradientEndColor, setGradientEndColor] = useState("#000000");
  const [imageURL, setImageURL] = useState("");
  const [outlineColor, setOutlineColor] = useState("#000000");
  const [outlineType, setOutlineType] = useState("solid");
  const [tempStrokeColor, setTempStrokeColor] = useState(strokeColor);
  const [tempStrokeWidth, setTempStrokeWidth] = useState(strokeWidth);
  const [tempFillColor, setTempFillColor] = useState(fillColor);
  const [tempOutlineColor, setTempOutlineColor] = useState(outlineColor);
  const [tempOutlineType, setTempOutlineType] = useState(outlineType);
  const [hatchType, setHatchType] = useState("diagonal");
  const [rightClickSelectedIdx, setRightClickSelectedIdx] = useState();
  const [rightClickSelected, setRightClickSelected] = useState();
  const [shapeComments, setShapeComments] = useState([]);
  // const [showContext,setShowContext] = useState(false)
  const [comment, setComment] = useState("");
  const [isShapeSelected, setIsShapeSelected] = useState(false);
  const [showRightCanvas, setShowRightCanvas] = useState(false);
  const [fontSize, setFontSize] = useState(16);
  const [fontColor,setFontColor] = useState("#000000");
  const [fontFamily,setFontFamily] = useState("helvetica")
  const [textAlign,setTextAlign]= useState("left")
  const [isBold,setIsBold]= useState(false)
  const [isUnderline,setIsUnderline]= useState(false)
  const [isItalic,setIsItalic]= useState(false)
  const [overline,setOverLine]= useState(false)
  const [linethrough, setLineThrough] =useState(false)







  // const [showCommentVisible,setshowCommentVisible]= useState("hidden");
  // const [currentCommentText,setCurrCommentText] = useState()

  // Add this state in the App component
  const [contextMenuPosition, setContextMenuPosition] = useState({
    x: 0,
    y: 0,
  });
  const options = [
    { label: "Duplicate", action: () => handleOption("Duplicate") },
    { label: "Delete", action: () => handleOption("Delete") },
    { label: "Add Comment", action: () => handleOption("Add Comment") },
  ];

  const [contextMenuOptions, setContextMenuOptions] = useState(options || []);
  const [isCommentAdd, setIsCommentAdd] = useState(false);
  const prevCordsRef = useRef();
  const line = useRef();
  const isDown = useRef();
  const vertices = useRef([]);
  const polygon = useRef();

  fabric.Object.prototype.noScaleCache = false;

  useEffect(() => {
    if (canvas) return;
    fabric.Object.prototype = {
      ...fabric.Object.prototype,
      transparentCorners: false,
      cornerStyle: "circle",
      cornerSize: 5,
    };
    setCanvas(
      new fabric.Canvas(`canvas`, {
        backgroundColor: "transparent",
        selection: false,
        renderOnAddRemove: true,
      })
    );
  }, []);

  const resetCanvas = () => {
    canvas.off();
    canvas.clear();
  };

  const resetVariables = () => {
    line.current = undefined;
    isDown.current = undefined;
    prevCordsRef.current = undefined;
    polygon.current = undefined;
    vertices.current = [];
  };

  const addVertice = (newPoint) => {
    if (vertices.current.length > 0) {
      const lastPoint = vertices.current[vertices.current.length - 1];
      if (lastPoint.x !== newPoint.x && lastPoint.y !== newPoint.y) {
        vertices.current.push(newPoint);
      }
    } else {
      vertices.current.push(newPoint);
    }
  };

  const drawPentagon = () => {
    const initialPoints = [];
    const radius = 100; // Radius of the circle containing the pentagon

    // Calculate the initial points of the pentagon
    for (let i = 0; i < 5; i++) {
      initialPoints.push({
        x: radius * Math.cos((2 * Math.PI * i) / 5),
        y: radius * Math.sin((2 * Math.PI * i) / 5),
      });
    }

    // Create a polygon with the initial points
    const pentagon = new fabric.Polygon(initialPoints, {
      fill: "", // Change fill color as needed
      stroke: "black", // Change stroke color as needed
      strokeWidth: 2, // Change stroke width as needed
      objectCaching: false,
      transparentCorners: false,
      cornerColor: "blue",
      hasBorders: true,
      cornerStyle: "rect",
    });

    // Calculate center coordinates of the canvas
    const canvasCenterX = canvas.width / 2;
    const canvasCenterY = canvas.height / 2;

    // Calculate the offset needed to position the pentagon at the center
    const offsetX = canvasCenterX - pentagon.width / 2;
    const offsetY = canvasCenterY - pentagon.height / 2;

    // Set the position of the pentagon
    pentagon.set({
      left: offsetX,
      top: offsetY,
    });

    // Add the pentagon to the canvas
    canvas.add(pentagon);
    addShape(pentagon);
  };

  // const showPolygon = () => {
  //   resetCanvas();

  //   if (!polygon.current) {
  //     polygon.current = new fabric.Polygon(vertices.current, {
  //       fill: "red",
  //       strokeWidth: 2,
  //       stroke: "black",
  //       objectCaching: false,
  //       transparentCorners: false,
  //       cornerColor: "blue",
  //       hasBorders: true,
  //       cornerStyle: "rect",
  //     });
  //   }

  //   polygon.current.controls = fabric.Object.prototype.controls;
  //   polygon.current.edit = false;
  //   polygon.current.hasBorders = true;
  //   polygon.current.cornerColor = "blue";
  //   polygon.current.cornerStyle = "rect";
  //   canvas.add(polygon.current);
  //   canvas.sendToBack(polygon.current);
  //   canvas.renderAll();
  // };

  function polygonPositionHandler(dim, finalMatrix, fabricObject) {
    let x = fabricObject.points[this.pointIndex].x - fabricObject.pathOffset.x,
      y = fabricObject.points[this.pointIndex].y - fabricObject.pathOffset.y;
    return fabric.util.transformPoint(
      {
        x: x,
        y: y,
      },
      fabric.util.multiplyTransformMatrices(
        fabricObject.canvas.viewportTransform,
        fabricObject.calcTransformMatrix()
      )
    );
  }

  function actionHandler(eventData, transform, x, y) {
    let polygon = transform.target,
      currentControl = polygon.controls[polygon.__corner],
      mouseLocalPosition = polygon.toLocalPoint(
        new fabric.Point(x, y),
        "center",
        "center"
      ),
      polygonBaseSize = polygon._getNonTransformedDimensions(),
      size = polygon._getTransformedDimensions(0, 0),
      finalPointPosition = {
        x:
          (mouseLocalPosition.x * polygonBaseSize.x) / size.x +
          polygon.pathOffset.x,
        y:
          (mouseLocalPosition.y * polygonBaseSize.y) / size.y +
          polygon.pathOffset.y,
      };
    polygon.points[currentControl.pointIndex] = finalPointPosition;
    return true;
  }

  function anchorWrapper(anchorIndex, fn) {
    return function (eventData, transform, x, y) {
      let fabricObject = transform.target,
        absolutePoint = fabric.util.transformPoint(
          {
            x: fabricObject.points[anchorIndex].x - fabricObject.pathOffset.x,
            y: fabricObject.points[anchorIndex].y - fabricObject.pathOffset.y,
          },
          fabricObject.calcTransformMatrix()
        ),
        actionPerformed = fn(eventData, transform, x, y),
        newDim = fabricObject._setPositionDimensions({}),
        polygonBaseSize = fabricObject._getNonTransformedDimensions(),
        newX =
          (fabricObject.points[anchorIndex].x - fabricObject.pathOffset.x) /
          polygonBaseSize.x,
        newY =
          (fabricObject.points[anchorIndex].y - fabricObject.pathOffset.y) /
          polygonBaseSize.y;
      fabricObject.setPositionByOrigin(absolutePoint, newX + 0.5, newY + 0.5);
      return actionPerformed;
    };
  }

  function editPolygon() {
    canvas.setActiveObject(polygon.current);

    polygon.current.edit = true;
    polygon.current.hasBorders = false;

    let lastControl = polygon.current.points.length - 1;
    polygon.current.cornerStyle = "circle";
    polygon.current.cornerColor = "rgba(0,0,255,0.5)";
    polygon.current.controls = polygon.current.points.reduce(function (
      acc,
      point,
      index
    ) {
      acc["p" + index] = new fabric.Control({
        positionHandler: polygonPositionHandler,
        actionHandler: anchorWrapper(
          index > 0 ? index - 1 : lastControl,
          actionHandler
        ),
        actionName: "modifyPolygon",
        pointIndex: index,
      });
      return acc;
    },
    {});

    canvas.requestRenderAll();
  }

  const toggleShapeVisibility = (index) => {
    const updatedVisibility = [...shapeVisibility];
    updatedVisibility[index] = !updatedVisibility[index];
    setShapeVisibility(updatedVisibility);

    const shape = shapes[index];
    shape.visible = updatedVisibility[index]; // Set visibility on the shape
    canvas.requestRenderAll();
  };

  const [showContext, setShowContext] = useState(false);

  useEffect(() => {
    if (showContext) {
      console.log("SEtting options");
      setContextMenuOptions(options);
    } else {
      setContextMenuOptions([]);
    }
  }, [showContext]);

  const handleContextMenu = (obj, idx, x, y, event) => {
    console.log("CON MENU CUSTOM", obj, idx, x, y, event);

    if (obj) {
      // event.preventDefault();
      setRightClickSelected(obj);
      setRightClickSelectedIdx(idx);
      // const pointer = canvas.getPointer(event.e, false);
      const windowX = event.e.clientX + window.pageXOffset;
      const windowY = event.e.clientY + window.pageYOffset;

      setContextMenuPosition({ x: windowX, y: windowY });
      setShowContext(true);
    } else {
      setShowContext(false);
    }
  };

  const resetShape = () => {
    setFillType("solid");
    setStrokeColor("#000");
    setStrokeWidth(2);
    setTempOutlineType("solid");
  };

  const handleOption = (option) => {
    switch (option) {
      case "Duplicate":
        duplicateShape(rightClickSelected);
        break;
      case "Delete":
        deleteSelectedShape();
        setShowContext(false);
        break;
      case "Add Comment":
        // setIsCommentAdd(true);
        console.log("Add comments fun fired", rightClickSelected);
        addComment(rightClickSelected);
        break;
      // Add more cases as needed
      default:
        break;
    }
  };

  useEffect(() => {
    const newCanvas = new fabric.Canvas("drawingCanvas", {
      backgroundColor: "#fff",
      width: 1000,
      height: 500,
      fireRightClick: true, // <-- enable firing of right click events
      fireMiddleClick: true, // <-- enable firing of middle click events
      stopContextMenu: true,
    });

    setCanvas(newCanvas);

    newCanvas.on("contextmenu", (e) => {
      e.preventDefault(); // Prevent the default context menu behavior
    });

    newCanvas.on("mousedown", () => {
      // Hide context menu options when clicking anywhere on the canvas
      setContextMenuOptions([]);
      setShowContext(false);
      setIsCommentAdd(false);
    });

    return () => {
      if (newCanvas) {
        newCanvas.off("contextmenu"); // Remove the contextmenu event listener when the component unmounts
        newCanvas.off("mousedown");
      }
    };
  }, []);

  const toggleRightCanvas = () => {
    setShowRightCanvas(!showRightCanvas);
  };

  useEffect(() => {
    if (canvas) {
      canvas.isDrawingMode = false;
    }
  }, [canvas]);

  useEffect(() => {
    if (canvas) {
      // Event listener for selection creation
      canvas.on("selection:created", handleSelection);
      // Event listener for selection update (e.g., when selecting a different shape)
      canvas.on("selection:updated", handleSelection);
      // Event listener for selection clear
      canvas.on("selection:cleared", handleSelectionClear);
      // canvas.on("mouse:down", handleRightClickOnShape);
      canvas.on("mouse:down", preventDefaultContextMenu);
    }

    return () => {
      if (canvas) {
        canvas.off("selection:created", handleSelection);
        canvas.off("selection:updated", handleSelection);
        canvas.off("selection:cleared", handleSelectionClear);

        // canvas.off("mouse:down", handleRightClickOnShape);
      }
    };
  }, [canvas, shapes]);

  const preventDefaultContextMenu = (event) => {
    event.e.preventDefault();
    // console.log("Inside fun", event.button, selectedShapeIndex);
    const selectedObject = event.target;
    const index = shapes.findIndex((shape) => shape === selectedObject);
    setSelectedShapeIndex(index);
    if (event.button === 1) {
      // Check if the right mouse button is pressed
      console.log("LEFT CLICKED", event, index);
      setShowContext(false);
      setIsCommentAdd(false);
      setRightClickSelected(null);
      setRightClickSelectedIdx(null);
    }
    if (event.button === 3) {
      // Check if the right mouse button is pressed
      console.log("RIGHT CLICKED", event);

      handleContextMenu(
        selectedObject,
        index,
        event.pointer.x,
        event.pointer.y,
        event
      );
    }
  };

  const handleSelection = (e) => {
    const selectedObject = e.target;
    const index = shapes.findIndex((shape) => shape === selectedObject);
    setSelectedShapeIndex(index);

    setIsShapeSelected(true);

    setFillTypeProperties(selectedObject);
    setStrokeColor(selectedObject?.stroke);
    setStrokeWidth(selectedObject.strokeWidth);
    setStrokeProperties(selectedObject);
    setOutlineColor("#000000");
    setFillEnabled(selectedObject?.fill || false);
    if(selectedObject?.text)
    {
       handleTextProperties(selectedObject)
    }

  };

  function handleTextProperties(selectedObject)
  {

 

    console.log("TEXT ONE ", selectedObject)
    setFontColor(selectedObject?.fill || "#000000")
    setFontFamily(selectedObject?.fontFamily || "helvetica")
    setTextAlign(selectedObject?.textAlign || "left")
    setFontSize(selectedObject?.fontSize || 16)

    if(selectedObject?.fontWeight==="bold")
    {
      setIsBold(true)
    }
    else{
      setIsBold(false)
    }
    if(selectedObject?.fontStyle==="italic")
    {
      setIsItalic(true)
    }
    else{
      setIsItalic(false)
    }
    if(selectedObject?.linethrough==="linethrough"){
    setLineThrough(true)
    }
    else{
    setLineThrough(false)

    }
    if(selectedObject?.overline==="overline"){
      setOverLine(true)
      }
      else{
        setOverLine(false)
      }
      if(selectedObject?.underline==="underline"){
        setIsUnderline(true)
        }
        else{
          setIsUnderline(false)
        }


   

  }

  function setFillTypeProperties(selectedObj) {
    console.log("SSSS", typeof selectedObj.fill, selectedObj);
    if (typeof selectedObj.fill === "string") {
      if (selectedObj.fill === "") {
        setFillColor("#ffffff");
      } else {
        setFillColor(selectedObj?.fill);
      }
      setFillType("solid");
    } else {
      if (selectedObj?.fill?.type) {
        if (selectedObj?.fill?.type === "linear") {
          setFillType("gradient");
          setGradientStartColor(
            selectedObj?.fill?.colorStops?.[0]?.color || "#ffffff"
          );
          setGradientEndColor(
            selectedObj?.fill?.colorStops?.[1]?.color || "#000000"
          );
        }
      } else if (selectedObj?.id || selectedObj?.repeat) {
        setFillType("hatch");
        if (selectedObj?.id === 1) {
          setHatchType("diagonal");
        } else if (selectedObj?.id === 2) {
          setHatchType("horizontal");
        } else if (selectedObj?.id === 2) {
          setHatchType("vertical");
        }
      } else {
        console.log("COMING H#RE XXXX");
        setFillType("solid");
      }
    }
  }
  function setStrokeProperties(selectedObj) {
    console.log("Storke props", selectedObj?.strokeDashArray);
    if (selectedObj?.strokeDashArray) {
      const strokeArr = selectedObj?.strokeDashArray;
      if (strokeArr[0] === 5 && strokeArr[1] === 5) {
        setOutlineType("dashed");
      } else {
        setOutlineType("dotted");
      }
    } else {
      setOutlineType("solid");
    }
  }

  const handleSelectionClear = () => {
    setSelectedShapeIndex(null);
    setIsShapeSelected(false);

    // Hide the comment text when no shape is selected
    setComment("");
  };

  const toggleEraserMode = () => {
    setEraserMode(!eraserMode);
    if (!canvas) return;
    canvas.isDrawingMode = false;
    canvas.freeDrawingBrush = eraserMode
      ? null
      : new fabric.PencilBrush(canvas);
    canvas.isDrawingMode = eraserMode;
  };

  const addShape = (shape) => {
    resetShape();
    if (!canvas) return;
    if (canvas.isDrawingMode) {
      canvas.isDrawingMode = false;
    }

    canvas.add(shape);
    canvas.setActiveObject(shape);
    setShapes([...shapes, shape]);
    setShapeVisibility([...shapeVisibility, true]); // Initialize visibility state for the shape
  };

  const duplicateShape = (shape) => {
    if (!canvas || !shape) return;
    if (canvas.isDrawingMode) {
      canvas.isDrawingMode = false;
    }

    fabric.util.enlivenObjects([shape.toObject()], (objects) => {
      const clonedShape = objects[0];
      if (!clonedShape) return;

      clonedShape.set({
        left: shape.left + 20,
        top: shape.top + 20,
      });

      canvas.add(clonedShape);
      setShapes([...shapes, clonedShape]);
      setShapeVisibility([...shapeVisibility, true]); // Initialize visibility state for the cloned shape
      canvas.renderAll();
    });
  };

  const removeShape = (shape) => {
    if (!canvas) return;
    canvas.remove(shape);
    setShapes(shapes.filter((item) => item !== shape));

    if (shapeComments.length > 0) {
      let newShapeComm = [];
      for (let i = 0; i < shapeComments.length; i++) {
        if (shapeComments[i].commentShape === shape) {
          canvas.remove(shapeComments[i].commentText);
        } else {
          newShapeComm.push(shapeComments[i]);
        }
      }
      setShapeComments(newShapeComm);
    }
    setSelectedShapeIndex(null); // Reset selected shape index
  };

  const addRect = () => {
    const fillValue = fillType === "image" ? createImageFill() : getFillValue();
    const rect = new fabric.Rect({
      ...defaultRectShapeValue,
    });
    addShape(rect);
  };

  const addStar = () => {
    const starPoints = [
      { x: 349.9, y: 75 },
      { x: 379, y: 160.9 },
      { x: 469, y: 160.9 },
      { x: 397, y: 214.9 },
      { x: 423, y: 300.9 },
      { x: 350, y: 249.9 },
      { x: 276.9, y: 301 },
      { x: 303, y: 215 },
      { x: 231, y: 161 },
      { x: 321, y: 161 },
    ];

    const star = new fabric.Polygon(starPoints, {
      ...defaultStarShapeValue,
    });

    addShape(star);
  };

  // Add octagon shape
  const addOctagon = () => {
    const octagonPoints = [
      { x: -37.282, y: 90 },
      { x: 37.282, y: 90 },
      { x: 90, y: 37.282 },
      { x: 90, y: -37.282 },
      { x: 37.282, y: -90 },
      { x: -37.282, y: -90 },
      { x: -90, y: -37.282 },
      { x: -90, y: 37.282 },
    ];

    const octagon = new fabric.Polygon(octagonPoints, {
      ...defaultOctagonShapeValue,
    });

    addShape(octagon);
  };

  const addCircle = () => {
    const fillValue = fillType === "image" ? createImageFill() : getFillValue();
    const circle = new fabric.Circle({
      ...defaultCircleShapeValue,
    });
    addShape(circle);
  };

  const addTriangle = () => {
    const fillValue = fillType === "image" ? createImageFill() : getFillValue();
    const triangle = new fabric.Triangle({
      ...defaultTriangleShapeValue,
    });
    addShape(triangle);
  };

  const addText = () => {
    const fillValue = fillType === "image" ? createImageFill() : getFillValue();
    const text = new fabric.IText("Enter text here", {
      ...defaultTextValue,
    });
    addShape(text);
  };


  
  const handleFontSizeChange = (value) => {
    setFontSize(value);
  };

  const handleColorChange = (property, value) => {
    if (canvas) {
      const activeObject = canvas.getActiveObject();
      if (activeObject) {
        activeObject.set(property, value);
        canvas.renderAll();
      }
    }
  };

  const handleFontStyleChange = (property, value) => {
    if (canvas) {
      const activeObject = canvas.getActiveObject();
      if (activeObject) {
        activeObject.set(property, value ? value : '');
        canvas.renderAll();
      }
    }
  };

  useEffect(()=>{
    handleFontSize("fontSize", fontSize);
  } , [fontSize])


  const handleFontSize = (property, value) => {
    if (canvas) {
      const activeObject = canvas.getActiveObject();
      if (activeObject) {
        activeObject.set(property, value ? value : '12');
        canvas.renderAll();
      }
    }
  };




  const handleCheckboxChange = (property, value) => {
    if (canvas) {
      const activeObject = canvas.getActiveObject();
      if (activeObject) {
        activeObject.set(property, value);
        canvas.renderAll();
      }
    }
  };

  const getFillValue = () => {
    switch (fillType) {
      case "solid":
        return fillEnabled ? fillColor : "";
      case "gradient":
        return createGradientFill();
      case "image":
        return createImageFill();
      case "hatch":
        return createHatchFill();
      default:
        return "";
    }
  };

  const createGradientFill = () => {
    const gradient = new fabric.Gradient({
      type: "linear",
      gradientUnits: "pixels",
      coords: { x1: 0, y1: 0, x2: 0, y2: 200 },
      colorStops: [
        { offset: 0, color: gradientStartColor },
        { offset: 1, color: gradientEndColor },
      ],
    });
    return gradient;
  };

  const createImageFill = () => {
    return imageURL;
  };

  const createHatchFill = () => {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    canvas.width = 20;
    canvas.height = 20;

    switch (hatchType) {
      case "diagonal":
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(20, 20);
        ctx.stroke();
        break;
      case "horizontal":
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;

        ctx.beginPath();
        ctx.moveTo(0, 10);
        ctx.lineTo(20, 10);
        ctx.stroke();
        break;
      case "vertical":
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;

        ctx.beginPath();
        ctx.moveTo(10, 0);
        ctx.lineTo(10, 20);
        ctx.stroke();
        break;
      default:
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(20, 20);
        ctx.stroke();
    }

    const pattern = new fabric.Pattern({
      source: canvas,
      repeat: "repeat",
    });

    return pattern;
  };

  const applyChanges = () => {
    const activeObject = canvas.getActiveObject();
    console.log("ACTIVE OBJ:", activeObject);

    if (activeObject) {
      // Modify properties of the selected object
      activeObject.set({
        stroke: tempStrokeColor,
        strokeWidth: tempStrokeWidth,
        fill: getFillValue(),
        strokeDashArray:
          tempOutlineType === "dashed"
            ? [5, 5]
            : tempOutlineType === "dotted"
            ? [1, 5]
            : null,
      });
      canvas.requestRenderAll();
    }
  };



  useEffect(() => {
    setTempStrokeColor(strokeColor);
  }, [strokeColor]);

  useEffect(() => {
    setTempStrokeWidth(strokeWidth);
  }, [strokeWidth]);

  useEffect(() => {
    setTempFillColor(fillColor);
  }, [fillColor]);

  useEffect(() => {
    setTempOutlineColor(outlineColor);
  }, [outlineColor]);

  useEffect(() => {
    setTempOutlineType(outlineType);
  }, [outlineType]);

  const handleScaling = (options) => {
    const target = options.target;
    if (target) {
      const scaleFactor = target.scaleY || 1; // Use scaleY for vertical scaling
      const originalFontSize = 20; // Adjust this value based on your initial font size

      // Set the font size based on the scaling factor
      target.set("fontSize", originalFontSize * scaleFactor);
      canvas.renderAll();
    }
  };

  const handleImageUpload = async (event) => {
    setFileUploaded(true);
    const file = event.target.files[0];

    if (!file) return;

    try {
      if (file.type.startsWith("image/")) {
        const imageUrl = await loadImageAsDataURL(file);
        addImageToCanvas(imageUrl);
      } else if (file.type === "application/pdf") {
        const reader = new FileReader();
        reader.onload = async (event) => {
          const typedArray = new Uint8Array(event.target.result);
          const pdfData = typedArray.buffer;

          const pdfDoc = await pdfjs.getDocument({ data: pdfData }).promise;
          const pdfPage = await pdfDoc.getPage(1);

          const viewport = pdfPage.getViewport({ scale: 1 });
          const canvasElement = document.createElement("canvas");
          const context = canvasElement.getContext("2d");
          canvasElement.width = viewport.width;
          canvasElement.height = viewport.height;

          await pdfPage.render({ canvasContext: context, viewport }).promise;

          const imageUrl = canvasElement.toDataURL("image/jpeg");
          addImageToCanvas(imageUrl);
        };
        reader.readAsArrayBuffer(file);
      }
    } catch (error) {
      console.error("Error handling image upload:", error);
    }
  };

  const addImageToCanvas = (imageUrl) => {
    fabric.Image.fromURL(imageUrl, (img) => {
      const pdfAspectRatio = img.height / img.width;
      const canvasWidth = 595; // A4 width in pixels
      const canvasHeight = canvasWidth * pdfAspectRatio;

      img.scaleToWidth(canvasWidth);
      img.scaleToHeight(canvasHeight);

      if (canvas.backgroundImage) {
        canvas.backgroundImage.setElement(img.getElement());
      } else {
        canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
      }

      canvas.requestRenderAll();
      setFileUploaded(true);
    });
  };

  const loadImageAsDataURL = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  };
  const clearCanvas = () => {
    if (!canvas) return;
    canvas.clear();
    setShapes([]);
  };

  const deleteSelectedShape = () => {
    const activeObject = canvas.getActiveObject();
    if (activeObject) {
      removeShape(activeObject);
    }
  };

  useEffect(() => {
    canvas?.on("selection:created", () => {
      document.addEventListener("keydown", handleKeyPress);
    });
    canvas?.on("selection:cleared", () => {
      document.removeEventListener("keydown", handleKeyPress);
    });

    return () => {
      document.removeEventListener("keydown", handleKeyPress);
    };
  }, [canvas]);

  const handleKeyPress = (event) => {
    if (event.key === "Delete") {
      deleteSelectedShape();
    } else if (event.key === "d" && event.ctrlKey) {
      const activeObject = canvas.getActiveObject();
    }
  };

  // used this useEffect for handling the freeform changes seperately
  useEffect(() => {
    if (canvas) {
      canvas.on("path:created", handlePathCreated);
    }

    return () => {
      if (canvas) {
        canvas.off("path:created", handlePathCreated);
      }
    };
  }, [canvas, shapes]);

  const handlePathCreated = (e) => {
    const path = e.path;
    addShape(path);
  };

  const toggleFreeformDrawing = () => {
    if (!canvas) return;

    canvas.isDrawingMode = !canvas.isDrawingMode;

    if (canvas.isDrawingMode) {
      canvas.on("path:created", handlePathCreated);
    } else {
      canvas.off("path:created", handlePathCreated);
    }
  };

  const saveAsImage = () => {
    if (!canvas) return;

    const dataURL = canvas.toDataURL({
      format: "jpeg",
      quality: 0.8,
    });

    const link = document.createElement("a");
    link.href = dataURL;
    link.download = "canvas_image.jpg";
    link.click();
  };

  useEffect(() => {
    if (canvas) {
      canvas.on("path:created", (e) => {
        const path = e.path;
        addShape(path);
      });
    }
  }, [canvas]);

  useEffect(() => {
    if (canvas) {
      // Event listener for object modification (e.g., shape moved)
      canvas.on("object:modified", handleObjectModified);
      // canvas.on("mouse:up", handleMouseUp);
    }

    return () => {
      if (canvas) {
        // Remove the event listeners when the component unmounts
        canvas.off("object:modified", handleObjectModified);
        // canvas.off("mouse:up", handleMouseUp);
      }
    };
  }, [canvas, shapes, shapeComments]);
  const [selectedCommentShape, setSelectedCommentShape] = useState();

  // const handleMouseUp = (e) => {
  //   // Get the final position of the shape after the user stops moving
  //   const finalPositionObject = e.target;
  //   console.log("Final position:", finalPositionObject, finalPositionObject);

  // };

  const handleObjectModified = (e) => {
    const modifiedObject = e.target;
    const modifiedObjectIndex = shapes.findIndex(
      (shape) => shape === modifiedObject
    );

    // Your logic for handling the modification of the shape
    console.log(
      `Shape at index ${modifiedObjectIndex} has been modified.`,
      modifiedObject,
      shapeComments
    );
    const modifiedShapeCommentIdx = shapeComments.findIndex(
      (shape) => shape.commentShape === modifiedObject
    );
    console.log("!@#$", modifiedShapeCommentIdx);

    if (modifiedShapeCommentIdx !== -1) {
      updateCommentShapePosition(
        modifiedShapeCommentIdx,
        shapeComments,
        modifiedObject.top,
        modifiedObject.left,
        modifiedObject
      );
    }
  };

  const updateCommentShapePosition = (
    indexToChange,
    shapeComments,
    newTop,
    newLeft,
    modifiedObject
  ) => {
    setShapeComments((prevShapeComments) => {
      const updatedComments = [...prevShapeComments];
      const commentObject = updatedComments[indexToChange];

      if (commentObject && commentObject.commentText) {
        // Update the position of the commentShape
        commentObject.commentText.set({
          left: newLeft + 100,
          top: newTop - 40,
        });

        // Update the commentShape reference
        commentObject.commentShape = modifiedObject;

        // Move the input focus along with the fabric text
        const canvas = commentObject.commentText.canvas;
        const activeObject = canvas.getActiveObject();

        if (activeObject && activeObject === commentObject.commentText) {
          canvas.discardActiveObject(); // Deselect the current active object
          canvas.setActiveObject(commentObject.commentText);
        }

        // Trigger a re-render of the canvas
        commentObject.commentText.setCoords(); // Update the coordinates
        commentObject.commentText.set({
          dirty: true,
          statefullCache: true,
        });

        canvas.requestRenderAll();
      }

      return updatedComments;
    });
  };

  function commentAlreadyExist(rightClickSelected) {
    if (rightClickSelected && shapeComments) {
      const alreadyExistIndex = shapeComments.findIndex(
        (shape) => shape.commentShape === rightClickSelected
      );
      if (alreadyExistIndex !== -1) {
        return shapeComments[alreadyExistIndex];
      } else {
        return null;
      }
    }
  }

  const [currCommentText, setCurrCommentText] = useState();

  const addComment = (rightClickSelected) => {
    if (!rightClickSelected || !canvas) {
      return;
    }
    setShowContext(false);

    const existingComment = commentAlreadyExist(rightClickSelected);

    if (existingComment) {
      // Edit existing comment
      updateComment(existingComment);
      setSelectedCommentShape(null);
      setCurrCommentText(null);
    } else {
      var comment = "Enter your comment...";
      const commentText = new fabric.IText(comment, {
        left: rightClickSelected.left + 100,
        top: rightClickSelected.top - 40,
        fontSize: 14,
        fill: "#333",
        width: 150,
        height: "auto",
        backgroundColor: "#f0f0f0",
        padding: 10,
        selectable: true,
        lockMovementX: true,
        lockMovementY: true,
        fontFamily: "Arial",
        fontWeight: "normal",
        fontStyle: "normal",
        textAlign: "left",
        visible: true,
      });

      commentText.on("changed", function (e) {
        const newText = commentText.text;
        setComment(newText);
        setShapeComments((prevShapeComments) => {
          const updatedComments = prevShapeComments.map((comment) => {
            if (comment.commentText === commentText) {
              // Update the comment text
              return { ...comment, comment: newText };
            }
            return comment;
          });

          return updatedComments;
        });

        commentText.canvas.requestRenderAll();
        // updateShapeCommentData(newText, shapeComments, rightClickSelected);
      });

      canvas.add(commentText);

      if (commentText) {
        const commentData = {
          comment: comment,
          commentShape: rightClickSelected,
          commentText: commentText,
        };
        setShapeComments((prevShapeComments) => [
          ...prevShapeComments.filter(
            (comment) => comment.commentShape !== rightClickSelected
          ),
          commentData,
        ]);
        setCurrCommentText(commentText);
        setSelectedCommentShape(rightClickSelected);
      }
    }
  };

  const updateComment = (commentData) => {
    if (commentData && commentData.commentText) {
      commentData.commentText.set({ text: commentData.comment });
      commentData.commentText.canvas.requestRenderAll();
    }
  };

  useEffect(() => {
    if (
      !canvas ||
      !currCommentText ||
      rightClickSelected ||
      !shapeComments.length < 1
    ) {
      console.log(
        "CHANIng commentsss",
        shapeComments,
        currCommentText,
        selectedCommentShape,
        comment
      );
    }
  }, [shapeComments, currCommentText, selectedCommentShape]);

  function updateShapeCommentData(newText, shapeComments, rightClickSelected) {
    if (shapeComments && rightClickSelected) {
      const modifiedShapeCommentIdx = shapeComments.findIndex(
        (shape) => shape.commentShape === rightClickSelected
      );
      console.log("!@#$ >>>>>>>>>>>", modifiedShapeCommentIdx);

      setShapeComments((prevShapeComments) => {
        const updatedComments = [...prevShapeComments];
        const commentObject = updatedComments[modifiedShapeCommentIdx];

        if (commentObject && commentObject.commentText) {
          // Update the position of the commentShape
         
          commentObject.comment = newText;
          // commentObject.commentShape = modifiedObject;

          // Trigger a re-render of the canvas
          commentObject.commentText.canvas.requestRenderAll();
        }
        console.log("RETURNING", updatedComments);
        return updatedComments;
      });
    }
  }

  console.log("1234", selectedShapeIndex);

  const props = {
    canvas,
    shapes,
    fillEnabled,
    eraserMode,
    freeformPath,
    canvasContainerRef,
    selectedShapeIndex,
    fileUploaded,
    fillType,
    strokeColor,
    strokeWidth,
    fillColor,
    gradientStartColor,
    gradientEndColor,
    imageURL,
    outlineColor,
    outlineType,
    hatchType,
    showRightCanvas,
    setShowRightCanvas,
    setHatchType,
    applyChanges,
    setOutlineType,
    setOutlineColor,
    setImageURL,
    setGradientStartColor,
    setGradientEndColor,
    setFillColor,
    setStrokeWidth,
    setFillType,
    setStrokeColor,
    addShape,
    setFillEnabled,
    saveAsImage,
    toggleFreeformDrawing,
    handleKeyPress,
    deleteSelectedShape,
    clearCanvas,
    loadImageAsDataURL,
    addImageToCanvas,
    handleImageUpload,
    addTriangle,
    addText,
    addCircle,
    addRect,
    setShapes,
    removeShape,
    duplicateShape,
    toggleEraserMode,
    createGradientFill,
    createHatchFill,
    shapeVisibility,
    setShapeVisibility,
    toggleShapeVisibility,
    handleCheckboxChange,
    handleFontStyleChange,
    handleColorChange,
    drawPentagon,
    addStar,
    fontSize, setFontSize,
    handleFontSizeChange,
    addOctagon,
    // showPolygon,
    editPolygon,
    onContextMenu: handleContextMenu,
    contextMenuOptions: contextMenuOptions,
    setContextMenuOptions: setContextMenuOptions,
    contextMenuPosition: contextMenuPosition,
    addComment: addComment,
    setRightClickSelected: setRightClickSelected,
    fontColor,setFontColor,
    linethrough, setLineThrough,
overline,setOverLine,
isItalic,setIsItalic,
isUnderline,setIsUnderline,
isBold,setIsBold,
textAlign,setTextAlign,
fontFamily,setFontFamily,
  };

  const handleContextMenu2 = (e) => {
    e.preventDefault();
    // Add any additional custom logic if needed
  };

  return (
    <div>
      {/* <SideMenus  /> */}
      <CanvasMain props={props} />

      {showContext && contextMenuOptions.length > 0 && (
        <div
          onContextMenu={handleContextMenu2}
          style={{
            position: "absolute",
            top: contextMenuPosition.y,
            left: contextMenuPosition.x,
            border: "1px solid #ccc",
            backgroundColor: "#fff",
            padding: "5px",
            zIndex: 1000,
            borderRadius: "6px",
          }}
        >
          {contextMenuOptions.map((option, index) => (
            <div
              key={index}
              onClick={option.action}
              className=""
              style={{
                cursor: "pointer",
                fontSize: "1rem",
                padding: "0.25rem 0.5rem",
              }}
            >
              {option.label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default App;
