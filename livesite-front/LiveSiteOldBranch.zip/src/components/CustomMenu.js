// CustomContextMenu.js
import React from "react";

const CustomMenu = ({ options, onSelect }) => {
  return (
    <div style={{ position: "absolute", zIndex: 1000 }}>
      <ul>
        {options.map((option, index) => (
          <li key={index} onClick={() => onSelect(option)}>
            {option.label}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CustomMenu;
