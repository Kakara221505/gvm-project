import React, { useState } from "react";

const Layer = ({shape,removeShape,duplicateShape,index,setShapeVisibility,shapeVisibility,toggleShapeVisibility,addComment,setRightClickSelected, currActiveOpt, setCurrentActiveOpt}) => {
const [showOpt,setShowOpt] = useState(false);

function handleLayerOptionClick()
{
  setCurrentActiveOpt(index)
  if(index===currActiveOpt){
  setShowOpt((prev) => !prev)
  }
  else{
    setShowOpt(true)
  }

}

function handleLayerRemove()
{
  removeShape(shape)
  setShowOpt(false)
   setCurrentActiveOpt(null) 
}




  return (
    <>
<div className="d-flex align-items-center gap-2 hover-layer position-relative">
  <div className="d-flex">
    <img
      src={shape.toDataURL()}
      alt="Shape"
      style={{ width: "20px", height: "20px" }}
      className="layer-icon"
    />
    <p className="m-0 fs-6 ps-2">Layer {index + 1}</p>
  </div>
</div>
  <div className="mb-1 " style={{ marginLeft: "auto" }}>
    <span
      className="hover-layer"
      onClick={handleLayerOptionClick}
    >
      ...
    </span>
  </div>


      {currActiveOpt === index && showOpt && (
        <div className="d-flex flex-column fs-6 border p-2 shadow position-absolute end-0 top-100 z-2 rounded-md bg-white pointer">
          <p onClick={handleLayerRemove} className="hover-layer my-2">
           
            Delete
          </p>
          <button className="bg-transparent border-0 me-auto ps-0" onClick={() => toggleShapeVisibility(index)}>
                {shapeVisibility[index] ? "Hide" : "Show"}
              </button>
          <p onClick={() => duplicateShape(shape)} className="hover-layer my-2">
            Duplicate
          </p>
          <p onClick={() => {
            setRightClickSelected(shape)
            addComment(shape)
          }} className="hover-layer my-2">
            Add Comment
          </p>
        </div>
      )}
    </>
  );
};

export default Layer;
