import React from 'react'

const Canva = ({canvasContainerRef}) => {
  return (
    <>
         <div ref={canvasContainerRef}>
      <canvas id="drawingCanvas"></canvas>
    </div>
    </>
  )
}

export default Canva