import React from 'react'

export default function PropertySettings() {
  return (
    <div>PropertySettings</div>
  )
}
