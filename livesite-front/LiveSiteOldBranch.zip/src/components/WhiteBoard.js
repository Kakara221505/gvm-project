import React from 'react'
// import CanvasMain from './Layout/CanvasMainLayout/CanvasMain';
// import SideMenus from './Layout/SideMenus/SideMenus';
import  { useState, useRef, useEffect } from "react";
import { fabric } from "fabric";
import { pdfjs } from "react-pdf";
import Canva from './Canva';

const WhiteBoard = () => {

    const [canvas, setCanvas] = useState(null);
    const [shapes, setShapes] = useState([]);
    const [eraserMode, setEraserMode] = useState(false);
    const [fillEnabled, setFillEnabled] = useState(false);
    const canvasContainerRef = useRef(null);
    const freeformPath = useRef(null);
  
  
    useEffect(() => {
      const newCanvas = new fabric.Canvas("drawingCanvas", {
        backgroundColor: "#fff",
        width: 800,
        height: 600,
      });
      setCanvas(newCanvas);
    }, []);
  
    useEffect(() => {
      if (canvas) {
        canvas.isDrawingMode = false;
      }
    }, [canvas]);
  
    const toggleEraserMode = () => {
      setEraserMode(!eraserMode);
      if (!canvas) return;
      canvas.isDrawingMode = false;
      canvas.freeDrawingBrush = eraserMode ? null : new fabric.PencilBrush(canvas);
      canvas.isDrawingMode = eraserMode;
    };
  
    const addShape = (shape) => {
      if (!canvas) return;
      if (canvas.isDrawingMode) {
        canvas.isDrawingMode = false;
      }
      canvas.add(shape);
      setShapes([...shapes, shape]);
    };
  
    const duplicateShape = (shape) => {
      if (!canvas || !shape) return;
      if (canvas.isDrawingMode) {
        canvas.isDrawingMode = false;
      }
    
      fabric.util.enlivenObjects([shape.toObject()], (objects) => {
        const clonedShape = objects[0];
        if (!clonedShape) return;
        
        clonedShape.set({
          left: shape.left + 20,
          top: shape.top + 20,
        });
        
        canvas.add(clonedShape);
        setShapes([...shapes, clonedShape]);
        canvas.renderAll();
      });
    };
    
  
    const removeShape = (shape) => {
      if (!canvas) return;
      canvas.remove(shape);
      setShapes(shapes.filter((item) => item !== shape));
    };
  
    const addRect = () => {
      const rect = new fabric.Rect({
        left: 100,
        top: 100,
        width: 100,
        height: 100,
        fill: fillEnabled ? "red" : "",
        stroke: "black",
        strokeWidth: 2,
      });
      addShape(rect);
    };
  
    const addCircle = () => {
      const circle = new fabric.Circle({
        left: 200,
        top: 200,
        radius: 50,
        fill: fillEnabled ? "blue" : "",
        stroke: "black",
        strokeWidth: 2,
      });
      addShape(circle);
    };
  
     const addTriangle = () => {
      const triangle = new fabric.Triangle({
        left: 300,
        top: 300,
        width: 100,
        height: 100,
        fill: fillEnabled ? "green" : "",
        stroke: "black",
        strokeWidth: 2,
      });
      addShape(triangle);
    };
  
    const addText = () => {
      const text = new fabric.Textbox("Enter text here", {
        left: 400,
        top: 400,
        fontSize: 20,
        fontFamily: "Arial",
        fill: fillEnabled ? "black" : "",
        stroke: "black",
        strokeWidth: 1,
      });
      addShape(text);
    };
  
    const handleImageUpload = async (event) => {
      const file = event.target.files[0];
      if (!file) return;
  
      try {
        if (file.type.startsWith("image/")) {
          const imageUrl = await loadImageAsDataURL(file);
          addImageToCanvas(imageUrl);
        } else if (file.type === "application/pdf") {
          const reader = new FileReader();
          reader.onload = async (event) => {
            const typedArray = new Uint8Array(event.target.result);
            const pdfData = typedArray.buffer;
  
            const pdfDoc = await pdfjs.getDocument({ data: pdfData }).promise;
            const pdfPage = await pdfDoc.getPage(1); 
  
            const viewport = pdfPage.getViewport({ scale: 1 });
            const canvasElement = document.createElement("canvas");
            const context = canvasElement.getContext("2d");
            canvasElement.width = viewport.width;
            canvasElement.height = viewport.height;
  
            await pdfPage.render({ canvasContext: context, viewport }).promise;
  
            const imageUrl = canvasElement.toDataURL("image/jpeg");
            addImageToCanvas(imageUrl);
          };
          reader.readAsArrayBuffer(file);
        }
      } catch (error) {
        console.error("Error handling image upload:", error);
      }
    };
  
    const addImageToCanvas = (imageUrl) => {
      fabric.Image.fromURL(imageUrl, (img) => {
        img.scaleToWidth(canvas.width / 2);
        addShape(img);
      });
    };
  
  
    const loadImageAsDataURL = (file) => {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(file);
      });
    };
    const clearCanvas = () => {
      if (!canvas) return;
      canvas.clear();
      setShapes([]);
    };
  
    const deleteSelectedShape = () => {
      const activeObject = canvas.getActiveObject();
      if (activeObject) {
        removeShape(activeObject);
      }
    };
  
    useEffect(() => {
      canvas?.on("selection:created", () => {
        document.addEventListener("keydown", handleKeyPress);
      });
      canvas?.on("selection:cleared", () => {
        document.removeEventListener("keydown", handleKeyPress);
      });
  
      return () => {
        document.removeEventListener("keydown", handleKeyPress);
      };
    }, [canvas]);
  
    const handleKeyPress = (event) => {
      if (event.key === "Delete") {
        deleteSelectedShape();
      } else if (event.key === "d" && event.ctrlKey) {
        const activeObject = canvas.getActiveObject();
      }
    };
  
    const toggleFreeformDrawing = () => {
      if (!canvas) return;
      canvas.isDrawingMode = !canvas.isDrawingMode;
    };
  
    const saveAsImage = () => {
      if (!canvas) return;
  
      const dataURL = canvas.toDataURL({
        format: "jpeg",
        quality: 0.8,
      });
  
      const link = document.createElement("a");
      link.href = dataURL;
      link.download = "canvas_image.jpg";
      link.click();
    };
  
    useEffect(() => {
      if (canvas) {
        canvas.on("path:created", (e) => {
          const path = e.path;
          addShape(path);
        });
      }
    }, [canvas]);

  return (
    <div>
  
    <div>WhiteBoard</div>
    <Canva canvasContainerRef={canvasContainerRef} />
    {/* <div ref={canvasContainerRef}>
      <canvas id="drawingCanvas"></canvas>
    </div> */}
        
  </div>
  )
}

export default WhiteBoard